"""Record every currently-failing test as a known issue.

    python tools/baseline.py            fast tier + modules
    python tools/baseline.py --all      everything, including the slow suite

Run once when adopting the suite, and again after a batch of fixes ships.
From then on the daily run reports only what is new.
"""
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XML = os.path.join(HERE, "out", "baseline.xml")
OUT = os.path.join(HERE, "known-issues.txt")

NOTES = [("salon_id_query_param", "D9 — service list leak, highest priority"),
         ("unknown_route", "D1 — 404 returns 200"),
         ("unknown_report_key", "D1 — 404 returns 200"),
         ("invalid_dates", "D3 — blank date defaults to today"),
         ("per_page", "D6 — two page-size limits"),
         ("business_hours", "D13 — weekday 9 accepted"),
         ("revenue_equals_payments", "D10 — Sales/Payments gap, cause unknown"),
         ("card_count_matches", "D11 — card count vs table count"),
         ("wrong_types_in_body", "D7 — 500 on a wrong field type"),
         ("hostile_filter", "D2 — 500 on an unknown filter value")]

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
args = ["-p", "no:cacheprovider", "-q", "--no-header", "--tb=no",
        f"--junitxml={XML}", "-n", "8"]
if "--all" not in sys.argv:
    args += ["-m", "not slow"]

print("running the suite to record what currently fails…")
subprocess.run([sys.executable, "-m", "pytest", *args], cwd=HERE)

failed = []
for case in ET.parse(XML).getroot().iter("testcase"):
    if case.find("failure") is not None or case.find("error") is not None:
        cls, name = case.get("classname", ""), case.get("name", "")
        parts = cls.split(".")
        f = "/".join(parts[:-1]) + ".py" if len(parts) > 1 else cls + ".py"
        failed.append(f"{f}::{name}")

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("# Known issues — every test failing when this baseline was taken.\n")
    fh.write("# Anything failing that is NOT listed here is NEW and worth reading.\n")
    fh.write("# Add the bug number after a '#'. Delete a line once the fix ships.\n#\n")
    fh.write(f"# {len(set(failed))} failing tests recorded.\n\n")
    for f in sorted(set(failed)):
        note = next((n for k, n in NOTES if k in f), "")
        fh.write(f"{f}  # {note}\n" if note else f"{f}\n")

print(f"recorded {len(set(failed))} known failures to known-issues.txt")
