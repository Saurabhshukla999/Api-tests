import csv, os, re, sys
import pytest

class Collect:
    def __init__(self): self.rows=[]
    def pytest_collection_modifyitems(self, items):
        for it in items:
            marks = sorted({m.name for m in it.iter_markers()})
            self.rows.append((it.nodeid, "|".join(marks)))

c = Collect()
pytest.main(["--collect-only", "-q", "-p", "no:cacheprovider", "-p", "no:html",
             "--override-ini", "addopts="], plugins=[c])

with open("/tmp/cases.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["nodeid", "markers"])
    w.writerows(c.rows)
print("ROWS:", len(c.rows))
