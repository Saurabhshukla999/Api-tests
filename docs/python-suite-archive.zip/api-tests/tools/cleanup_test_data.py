"""Remove what the suite created, so it does not pile up on a shared salon.

    python tools/cleanup_test_data.py            show what would go
    python tools/cleanup_test_data.py --delete   actually remove it

Anything the suite creates is named with one of the prefixes below, so this can
never touch a real record. Settled bills are reported but never deleted — the
API refuses, correctly, and a suite should not be able to erase an invoice.

This is a workaround, not a fix. The real answer is a dedicated QA salon that
can be restored; see docs/TEST_ENVIRONMENT_REQUEST.md.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dotenv import load_dotenv                                    # noqa: E402
from lib.client import ApiClient                                  # noqa: E402

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(HERE, ".env"))

PREFIXES = ("APITEST", "JNEG", "JARITH", "JREF", "JNEGP")
DELETE = "--delete" in sys.argv

api = ApiClient(os.getenv("BASE_URL"), os.getenv("OWNER_TOKEN"), 30, "cleanup")
SALON = os.getenv("OWNER_SALON_ID")


def rows(result, *keys):
    d = result.data
    if isinstance(d, list):
        return d
    if isinstance(d, dict):
        for k in keys:
            if isinstance(d.get(k), list):
                return d[k]
        return next((v for v in d.values() if isinstance(v, list)), [])
    return []


def is_ours(record):
    name = str(record.get("name") or record.get("full_name") or "")
    return any(p in name for p in PREFIXES)


def sweep(label, list_call, delete_path, path_key="id", extra=None):
    found = [r for r in rows(list_call(), *(extra or [])) if isinstance(r, dict) and is_ours(r)]
    print(f"\n{label}: {len(found)} created by the suite")
    if not found:
        return 0
    removed = 0
    for r in found[:200]:
        nm = str(r.get("name") or r.get("full_name"))[:44]
        if not DELETE:
            print(f"  would remove  {r.get('id'):<8} {nm}")
            continue
        pp = {"salon_id": SALON, path_key: r.get("id")} if "{salon_id}" in delete_path \
            else {path_key: r.get("id")}
        d = api.delete(delete_path, path_params=pp)
        ok = d.status in (200, 204)
        removed += ok
        print(f"  {'removed ' if ok else f'kept({d.status})'}  {r.get('id'):<8} {nm}")
    return removed


total = 0
total += sweep("Services",
               lambda: api.get("/salon_services", params={"salon_id": SALON, "per_page": 300}),
               "/salon_services/{id}", extra=["salon_services", "items"])

total += sweep("Beauticians",
               lambda: api.get("/salons/{salon_id}/staff", path_params={"salon_id": SALON},
                               params={"per_page": 200}),
               "/salons/{salon_id}/staff/{id}", extra=["staff", "items"])

total += sweep("Customers",
               lambda: api.get("/salons/{salon_id}/salon_customer_profiles",
                               path_params={"salon_id": SALON}, params={"per_page": 200}),
               "/salons/{salon_id}/salon_customer_profiles/{id}",
               extra=["salon_customer_profiles", "items"])

# Bills: drafts can go, settled ones cannot and should not.
bills = api.get("/api/v1/billing/bills", params={"per_page": 200, "status": "draft"})
drafts = [b for b in rows(bills, "bills", "items") if isinstance(b, dict)]
print(f"\nDraft bills: {len(drafts)} (deletable)")
if DELETE:
    for b in drafts[:100]:
        d = api.delete("/api/v1/billing/bills/{id}", path_params={"id": b.get("id")})
        total += d.status in (200, 204)

settled = api.get("/api/v1/billing/bills", params={"per_page": 1, "status": "paid"})
meta = (settled.json or {}).get("meta") or {}
print(f"Settled bills: {meta.get('total_count')} — cannot be deleted, by design.")
print("  These accumulate on a shared salon. That is the case for a dedicated one.")

print(f"\n{'removed' if DELETE else 'would remove'} {total} records"
      + ("" if DELETE else "\n\nRe-run with --delete to actually remove them."))
