"""Regenerate docs/TEST_CASE_LIST.xlsx from the suite itself.

    python tools/export_case_list.py

Run it after adding tests so the list can never drift from the code.
"""
import csv, os, re, sys
import pytest

class Collect:
    def __init__(self): self.rows=[]
    def pytest_collection_modifyitems(self, items):
        for it in items:
            marks = sorted({m.name for m in it.iter_markers()})
            self.rows.append((it.nodeid, "|".join(marks)))

c = Collect()
pytest.main(["--collect-only", "-q", "-p", "no:cacheprovider", "-p", "no:html",
             "--override-ini", "addopts="], plugins=[c])

import os
os.makedirs("docs", exist_ok=True)
with open("docs/cases.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["nodeid", "markers"])
    w.writerows(c.rows)
print("ROWS:", len(c.rows))


# Build the workbook straight after collecting, so one command does both.
import subprocess, sys as _sys, os as _os
_here = _os.path.dirname(_os.path.abspath(__file__))
subprocess.run([_sys.executable, _os.path.join(_here, "_build_case_workbook.py")], check=True)
