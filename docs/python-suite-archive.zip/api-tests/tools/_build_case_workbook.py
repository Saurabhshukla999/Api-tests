import csv, re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

A="Arial"
HF=PatternFill("solid",fgColor="1F3B4D"); HFONT=Font(name=A,bold=True,color="FFFFFF",size=10)
TITLE=Font(name=A,bold=True,size=14,color="1F3B4D"); SUB=Font(name=A,size=10,color="555555")
BODY=Font(name=A,size=10); BOLD=Font(name=A,size=10,bold=True); BLUE=Font(name=A,size=10,color="0000FF")
BAND=PatternFill("solid",fgColor="F2F6F8"); YEL=PatternFill("solid",fgColor="FFF2CC")
TH=Side(style="thin",color="D0D7DE"); BD=Border(left=TH,right=TH,top=TH,bottom=TH)
WRAP=Alignment(wrap_text=True,vertical="top"); TOP=Alignment(vertical="top"); CTR=Alignment(horizontal="center",vertical="top")

rows=list(csv.DictReader(open("docs/cases.csv",encoding="utf-8")))

SUITE={"test_contract_auth":"Authentication","test_contract_tenant":"Salon isolation",
       "test_contract_idor":"Salon isolation","test_contract_schema":"Response contract",
       "test_contract_robustness":"Bad input","test_00_smoke":"Smoke",
       "test_arithmetic":"Money maths","test_reconciliation":"Reconciliation",
       "test_salon_journey":"End-to-end day"}
MODULE={"test_dashboard":"Business Dashboard","test_reports":"Reports","test_billing":"Billing",
        "test_salon_setup":"Salon Setup","test_attendance":"Attendance",
        "test_appointment_calendar":"Appointment Calendar","test_settings":"Salon Settings"}

def humanise(fn):
    s=re.sub(r"^test_\d*[a-z]?_?","",fn).replace("_"," ").strip()
    return (s[:1].upper()+s[1:]) if s else fn

def endpoint_of(param):
    m=re.search(r"(GET|POST|PUT|PATCH|DELETE) (/\S+?)(?:\]|$|-)",param or "")
    return f"{m.group(1)} {m.group(2)}" if m else ""

recs=[]
for r in rows:
    node=r["nodeid"]; marks=set((r["markers"] or "").split("|"))-{"parametrize",""}
    path,_,rest=node.partition("::")
    fn,_,param=rest.partition("[")
    param=param[:-1] if param.endswith("]") else param
    stem=path.split("/")[-1].replace(".py","")
    suite=SUITE.get(stem) or MODULE.get(stem) or stem
    kind="Business rules" if stem in MODULE else "Generated"
    fast = bool(marks & {"smoke","auth","tenant","arithmetic"}) and "slow" not in marks
    recs.append({
        "suite":suite, "kind":kind, "file":path, "fn":fn,
        "checks":humanise(fn), "param":param, "endpoint":endpoint_of(param),
        "marks":", ".join(sorted(marks)) or "—",
        "tier":"Fast (on change)" if fast else "Nightly",
        "destructive":"Yes" if "destructive" in marks else "No",
        "slow":"Yes" if "slow" in marks else "No",
        "node":node,
    })
recs.sort(key=lambda x:(x["suite"], x["fn"], x["param"]))
for i,rec in enumerate(recs,1): rec["id"]=f"NZ-{i:04d}"

wb=Workbook()

# ---- Read me
ws=wb.active; ws.title="Read me"
L=[("Nearz B2B — API test case list",None),
   (f"{len(recs):,} test cases, exported from the suite itself on 27 Aug 2026.",None),
   (None,None),
   ("What this is",None),
   (None,"Every test the suite runs, one per row. Exported straight from pytest, so it cannot drift from the code."),
   (None,"Regenerate any time:  python tools/export_case_list.py"),
   (None,None),
   ("Running one case",None),
   (None,'Copy the "Run this" cell and paste it after pytest. Example:'),
   (None,'   pytest "tests/test_contract_auth.py::test_rejects_missing_token[GET /salons/{salon_id}/products]"'),
   (None,None),
   ("Running a group",None),
   (None,"pytest -m auth            all authentication cases"),
   (None,"pytest -m arithmetic      all money maths cases"),
   (None,"pytest -k billing         anything with billing in the name"),
   (None,None),
   ("Tiers",None),
   (None,'Fast (on change)  — smoke, auth, salon isolation, money maths. Measured 58 seconds.'),
   (None,'Nightly           — everything, including the slow bad-input suite.'),
   (None,None),
   ("Columns you fill in",None),
   (None,"Status / Last run / Notes are yellow and left blank — for tracking a run by hand."),
   (None,"A normal automated run fills these itself in reports/report.html."),
   (None,None),
   ("One rule",None),
   (None,'A case that only checks "it returned an error" is half a test.'),
   (None,'The other half is whether the data is still consistent afterwards.')]
ws["A1"].font=TITLE; ws["A2"].font=SUB
for i,(a,b) in enumerate(L,1):
    if a:
        c=ws.cell(row=i,column=1,value=a)
        c.font = TITLE if i==1 else (SUB if i==2 else BOLD)
    if b: c=ws.cell(row=i,column=2,value=b); c.font=BODY; c.alignment=WRAP
ws.column_dimensions["A"].width=24; ws.column_dimensions["B"].width=100

# ---- Summary
sm=wb.create_sheet("Summary")
sm["A1"]="Where the cases are"; sm["A1"].font=TITLE
sm["A2"]="Counts are live formulas over the case list."; sm["A2"].font=SUB
for j,h in enumerate(["Suite","What it checks","Cases","Fast tier","Nightly","Destructive"],1):
    c=sm.cell(row=4,column=j,value=h); c.font=HFONT; c.fill=HF; c.border=BD; c.alignment=CTR
DESC={"Authentication":"Every endpoint refuses a missing, bad or forged login",
 "Salon isolation":"One salon cannot reach another salon's data",
 "Response contract":"Replies match the published API documentation",
 "Bad input":"Malformed values, bad page numbers, injection strings — must never crash",
 "Money maths":"Billing arithmetic checked to the paisa",
 "Reconciliation":"The same number agrees on every screen that reports it",
 "End-to-end day":"Create, book, assign staff, bill, settle — then check the reports",
 "Smoke":"Is the configuration working at all",
 "Business Dashboard":"Range handling, caching, throttling, Action Center",
 "Reports":"11 reports: summaries, rows, filters, downloads",
 "Billing":"Totals, discounts, refunds, invoices",
 "Salon Setup":"Services, products, beauticians, bulk upload",
 "Attendance":"Dates, upsert, exports","Appointment Calendar":"Bookings, conflicts, waitlist",
 "Salon Settings":"Hours, holidays, roles, GST"}
suites=sorted({r["suite"] for r in recs})
LAST=4+len(recs)
r0=5
for s in suites:
    sm.cell(row=r0,column=1,value=s).font=BOLD
    sm.cell(row=r0,column=2,value=DESC.get(s,"")).font=BODY
    sm.cell(row=r0,column=2).alignment=WRAP
    sm.cell(row=r0,column=3,value=f"=COUNTIF('All test cases'!$B$5:$B${LAST},$A{r0})").font=BODY
    sm.cell(row=r0,column=4,value=f"=COUNTIFS('All test cases'!$B$5:$B${LAST},$A{r0},'All test cases'!$I$5:$I${LAST},\"Fast (on change)\")").font=BODY
    sm.cell(row=r0,column=5,value=f"=COUNTIFS('All test cases'!$B$5:$B${LAST},$A{r0},'All test cases'!$I$5:$I${LAST},\"Nightly\")").font=BODY
    sm.cell(row=r0,column=6,value=f"=COUNTIFS('All test cases'!$B$5:$B${LAST},$A{r0},'All test cases'!$J$5:$J${LAST},\"Yes\")").font=BODY
    for j in range(1,7):
        sm.cell(row=r0,column=j).border=BD
        if j>=3: sm.cell(row=r0,column=j).alignment=CTR
    r0+=1
sm.cell(row=r0,column=1,value="TOTAL").font=BOLD; sm.cell(row=r0,column=1).border=BD
sm.cell(row=r0,column=2,value="").border=BD
for j,col in ((3,"C"),(4,"D"),(5,"E"),(6,"F")):
    c=sm.cell(row=r0,column=j,value=f"=SUM({col}5:{col}{r0-1})"); c.font=BOLD; c.border=BD; c.alignment=CTR
for col,w in zip("ABCDEF",(22,58,9,11,10,12)): sm.column_dimensions[col].width=w

# ---- All test cases
tc=wb.create_sheet("All test cases")
tc["A1"]=f"All {len(recs):,} test cases"; tc["A1"].font=TITLE
tc["A2"]="Filter by Suite, Tier or Destructive. Paste the last column after pytest to run one case."; tc["A2"].font=SUB
HDR=["Case ID","Suite","Type","What it checks","Applied to","Endpoint","Markers","File",
     "Tier","Destructive","Slow","Status","Last run","Notes","Run this"]
for j,h in enumerate(HDR,1):
    c=tc.cell(row=4,column=j,value=h); c.font=HFONT; c.fill=HF; c.border=BD; c.alignment=CTR
for i,rec in enumerate(recs,start=5):
    vals=[rec["id"],rec["suite"],rec["kind"],rec["checks"],rec["param"],rec["endpoint"],
          rec["marks"],rec["file"].replace("tests/",""),rec["tier"],rec["destructive"],
          rec["slow"],"","","",f'"{rec["node"]}"']
    for j,v in enumerate(vals,1):
        c=tc.cell(row=i,column=j,value=v); c.font=BODY; c.border=BD
        c.alignment = WRAP if j in (4,5,15) else (CTR if j in (1,3,9,10,11,12) else TOP)
        if j in (12,13,14): c.fill=YEL
    if i%2==0:
        for j in range(1,12): tc.cell(row=i,column=j).fill=BAND
for col,w in zip("ABCDEFGHIJKLMNO",(10,20,14,40,44,30,26,26,15,11,7,9,11,20,60)):
    tc.column_dimensions[col].width=w
tc.freeze_panes="D5"
tc.auto_filter.ref=f"A4:O{LAST}"

out="docs/TEST_CASE_LIST.xlsx"
wb.save(out)
print("wrote", out, len(recs), "cases across", len(suites), "suites")
