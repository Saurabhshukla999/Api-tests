"""The one command QA runs.

    python tools/daily.py              the fast tier
    python tools/daily.py --full       everything, including destructive journeys
    python tools/daily.py --module billing

Runs the suite in TWO phases, then writes out/new-failures.md containing only
what is new since the baseline. On most mornings that file says "no new
failures" and you are done.

Why two phases
--------------
Contract tests only read, so eight of them can run at once safely.

Journeys cannot. A journey takes a snapshot of the salon's reports, performs
one business action, snapshots again, and asserts the reports moved by exactly
that action's amount. Run eight journeys at once against the same salon and
each one sees the other seven's money in its "after" snapshot, so every exact
-delta assertion fails. Measured on 2026-08-28: 18 such tests failed under
-n 8 and all 82 passed serially. Those were never real defects.

The day we get a dedicated test salon per worker, phase 2 can go parallel too.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(HERE, "out", "run.log")

argv = sys.argv[1:]
selector = ["-m", "P1"]
full = "--full" in argv
if full:
    selector = []
    argv.remove("--full")
if "--module" in argv:
    i = argv.index("--module")
    selector = ["-m", f"module_{argv[i + 1]}"]

extra = ["--run-destructive"] if full else []
COMMON = ["-q", "--no-header", "--tb=short", "-rf", "-p", "no:cacheprovider"]

PHASES = [
    # (label, paths, parallelism)
    ("contract  (read-only, parallel)", ["tests/test_00_smoke.py",
                                         "tests/test_contract_auth.py",
                                         "tests/test_contract_idor.py",
                                         "tests/test_contract_tenant.py"], ["-n", "8"]),
    ("journeys  (mutating, serial)",    ["tests/journeys"],                 []),
]

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
worst = 0

with open(LOG, "w", encoding="utf-8") as fh:
    for label, paths, parallel in PHASES:
        cmd = [sys.executable, "-m", "pytest", *paths, *selector,
               *COMMON, *parallel, *extra]
        banner = f"\n===== {label} =====\n{' '.join(cmd)}\n"
        sys.stdout.write(banner)
        fh.write(banner)

        proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        for line in proc.stdout:
            sys.stdout.write(line)
            fh.write(line)
        proc.wait()
        # 5 = "no tests collected", which is fine when a --module filter
        # matches nothing in one phase.
        if proc.returncode not in (0, 5):
            worst = max(worst, proc.returncode)

print()
subprocess.run([sys.executable, os.path.join(HERE, "tools", "new_failures.py")], cwd=HERE)
sys.exit(worst)
