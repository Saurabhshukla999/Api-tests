"""Turn a test run into 'what is new', by diffing it against known-issues.txt.

    python tools/daily.py            runs the suite and does this for you

Or, if you ran pytest yourself with `-rf` and tee'd the output:

    pytest -rf ... | tee out/run.log
    python tools/new_failures.py

Reads pytest's own `FAILED …` summary lines rather than the JUnit XML: those
lines carry the exact node id, they are printed by the master process so they
survive `-n 8`, and this pytest's XML does not record the file path reliably.
"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(HERE, "out", "run.log")
BASELINE = os.path.join(HERE, "known-issues.txt")
OUT = os.path.join(HERE, "out", "new-failures.md")


def load_baseline():
    known = {}
    if not os.path.exists(BASELINE):
        return known
    for line in open(BASELINE, encoding="utf-8"):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        nodeid, _, note = line.partition("  #")
        known[nodeid.strip()] = note.strip() or "no bug reference"
    return known


def failures_from(log_path):
    if not os.path.exists(log_path):
        print(f"no run log at {log_path} — use tools/daily.py, or pipe pytest "
              f"output through `tee out/run.log`")
        sys.exit(1)
    out = set()
    for line in open(log_path, encoding="utf-8", errors="ignore"):
        if line.startswith("FAILED "):
            out.add(line[len("FAILED "):].split(" - ")[0].strip())
    return out


def main():
    known = load_baseline()
    failed = failures_from(LOG)

    new = sorted(failed - set(known))
    still = sorted(failed & set(known))
    # A known failure that did not fail this run has probably been fixed. We can
    # only say that for tests that actually ran, so this is a hint, not a claim.
    absent = sorted(set(known) - failed)

    L = ["# What changed", ""]
    if not known:
        L += ["No baseline recorded. Create one with `python tools/baseline.py`,",
              "otherwise every failure below reads as new.", ""]
    if new:
        L += [f"## {len(new)} NEW — read these", ""] + [f"- `{n}`" for n in new]
    else:
        L += ["## No new failures", "", "Everything that failed was already known.", ""]
    if absent:
        L += ["", f"## {len(absent)} known failures did not fail this run", "",
              "If they were part of this run, a fix has shipped — delete them from",
              "known-issues.txt so a regression fails loudly again.", ""]
        L += [f"- `{n}`  ({known[n]})" for n in absent[:40]]
    if still:
        L += ["", f"_{len(still)} known failures still failing, as expected._"]

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"{len(new)} new · {len(still)} known · {len(absent)} not seen this run")
    print(f"wrote {os.path.relpath(OUT, HERE)}")
    return 1 if new else 0


if __name__ == "__main__":
    sys.exit(main())
