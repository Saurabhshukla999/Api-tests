# Nearz B2B API test suite

Automated API-level tests for the seven modules of the B2B salon-management
dashboard. Driven by `swagger/v1/*.json`, so the endpoint list can never drift
from the spec the backend publishes.

**2,003 tests from ~1,500 lines of code.** Testing 176 endpoints by hand is
weeks of work; this runs in minutes.

---

## Setup (5 minutes)

```bash
cd api-tests
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

Then fill in `.env`. The two values you cannot skip:

| Variable | Where to get it |
|---|---|
| `BASE_URL` | Open the QA dashboard, DevTools → Network → click any XHR → copy scheme + host from the Request URL. This is the API host, **not** the netlify URL. |
| `OWNER_TOKEN` + `OWNER_SALON_ID` | Same request: `Authorization: Bearer <token>` header, and the salon id in the path. |

Add `OTHER_TOKEN` + `OTHER_SALON_ID` for a **second salon owned by a different
user** as soon as you can get one. Without it the tenant-isolation and IDOR
tests skip — and those are the tests that find what UI testing structurally
cannot.

## The daily command

```bash
python tools/daily.py              # the P1 tier — about a minute
python tools/daily.py --full       # everything
python tools/daily.py --module billing
```

Then read **`out/new-failures.md`** — it lists only what is new since the
baseline. On most mornings it says "no new failures" and you are done.

Set the baseline once, and again after a batch of fixes ships:

```bash
python tools/baseline.py           # records what currently fails
```

Housekeeping, when the QA salon gets cluttered:

```bash
python tools/cleanup_test_data.py            # show what the suite created
python tools/cleanup_test_data.py --delete   # remove it
```

## Running pytest directly

```bash
pytest                          # everything non-destructive (~1,800 tests)
pytest -m smoke                 # 4 tests: is the config right?
pytest -m "auth or tenant"      # the security boundary
pytest -m functional            # business logic, per module
pytest -m "not slow"            # skip rate-limit and year-range tests
pytest --run-destructive        # include tests that create/modify data
pytest -n 8                     # parallel (pytest-xdist)
pytest -k billing               # one module
pytest --lf                     # re-run last failures only
pytest -m P1                    # critical only — money, security, core flow
pytest -m module_billing        # one module
```

An HTML report lands in `reports/report.html` after every run.

**Start with `pytest -m smoke`.** If those four fail, every other failure is
noise from a bad `.env`.

## Layout

```
lib/spec_loader.py    parses swagger/v1 -> Endpoint objects (the whole suite reads this)
lib/client.py         requests wrapper: path params, timing, readable failures
lib/auth.py           token acquisition, both paths
lib/paramfill.py      how generated tests fill params; hostile string catalogue
conftest.py           fixtures: api, api_other, api_anon, api_admin, salon_id
tests/test_00_smoke.py          config sanity - run first
tests/test_contract_*.py        generated: every endpoint, every run
tests/modules/test_*.py         hand-written business logic, one file per module
tools/build_inventory.py        regenerates docs/endpoint_inventory.csv + coverage_gaps.md
docs/API_TEST_PLAN.md           the plan to hand your lead
```

## Adding tests

- **A new endpoint appears in swagger** → nothing to do. Every contract test
  picks it up on the next run.
- **A business rule to check** → add a function to the right file in
  `tests/modules/`. Use the `api` fixture; mark it `@pytest.mark.destructive`
  if it writes.
- **Sending a request body?** Start from the spec, never from memory:
  `documented_body("PUT /salons/{salon_id}/attendance/entries")` in
  `lib/spec_loader.py`. Every payload mistake in this suite came from
  inventing a shape instead of reading one.
- **Regenerate the inventory** → `python3 tools/build_inventory.py`

## CI

```yaml
- run: pip install -r api-tests/requirements.txt
- run: pytest api-tests -m "not destructive and not slow" -n 8
  env:
    BASE_URL: ${{ secrets.QA_API_URL }}
    OWNER_MOBILE: ${{ secrets.QA_OWNER_MOBILE }}      # login path; tokens expire
    OTHER_MOBILE: ${{ secrets.QA_OTHER_MOBILE }}
```

Use the `OWNER_MOBILE` login path in CI rather than pasted tokens — a JWT here
lasts 24 hours, a mobile number lasts forever.
