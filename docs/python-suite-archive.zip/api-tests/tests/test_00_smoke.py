"""Runs first. If these fail, nothing else is worth reading."""
import pytest

from lib.spec_loader import load_endpoints

pytestmark = pytest.mark.smoke


def test_api_is_reachable(api_anon):
    r = api_anon.get("/health")
    assert r.status < 500, "the API is not answering" + r.explain()


def test_owner_token_is_accepted(api, salon_id):
    r = api.get("/salons/{salon_id}/dashboard/meta", path_params={"salon_id": salon_id})
    assert r.status == 200, (
        "OWNER_TOKEN/OWNER_SALON_ID do not work together - fix .env before "
        "reading any other failure" + r.explain())


def test_swagger_spec_loads():
    eps = load_endpoints()
    assert len(eps) > 150, f"only {len(eps)} endpoints parsed from swagger/v1"


def test_second_salon_is_configured(other_identity, owner_identity):
    if not other_identity:
        pytest.skip("OTHER_TOKEN not set - tenant isolation tests will not run")
    assert other_identity["salon_id"] != owner_identity["salon_id"], \
        "OTHER_SALON_ID must be a different salon than OWNER_SALON_ID"
