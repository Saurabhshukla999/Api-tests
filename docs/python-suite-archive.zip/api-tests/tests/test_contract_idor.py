"""IDOR: reaching another salon's records by guessing or reusing their id.

21 B2B endpoints take a record id with no salon anywhere in the path -
/api/v1/billing/bills/{id}, /appointments/{id}, /customer_memberships/{id},
/salon_services/{id}. For those, the ONLY thing keeping salon A out of salon
B's data is an ownership check inside that specific action. There is no shared
concern enforcing it and no route pattern that makes a missing check obvious in
review.

The UI can never produce these requests: it only ever renders ids it was given.
This file discovers a real id as salon B, then asks for it as salon A.
"""
import pytest

from lib.paramfill import UNLIKELY_ID
from lib.spec_loader import load_endpoints, ids

pytestmark = [pytest.mark.contract, pytest.mark.tenant]

DENIED = {401, 403, 404}

UNSCOPED = [e for e in load_endpoints() if e.unscoped_object]
UNSCOPED_READS = [e for e in UNSCOPED if e.is_safe]
UNSCOPED_WRITES = [e for e in UNSCOPED if not e.is_safe]

SALON_IN_QUERY = [e for e in load_endpoints() if not e.salon_scoped and e.salon_in_query]


def _first_id(result):
    data = result.data
    if isinstance(data, dict):
        for key in ("bills", "items", "records", "results", "rows", "data"):
            if isinstance(data.get(key), list) and data[key]:
                data = data[key]
                break
    if isinstance(data, list) and data:
        first = data[0]
        if isinstance(first, dict):
            return first.get("id") or first.get("uuid")
    return None


@pytest.fixture(scope="session")
def victim_ids(api_other, other_salon_id):
    """Real record ids belonging to salon B, harvested with B's own token."""
    found = {}
    probes = {
        "bill": ("/api/v1/billing/bills", {}, {}),
        "appointment": ("/salons/{id}/appointments", {"id": other_salon_id}, {}),
        "membership": ("/salons/{salon_id}/customer_memberships",
                       {"salon_id": other_salon_id}, {}),
        "service": ("/salon_services", {}, {"salon_id": other_salon_id}),
        "customer": ("/api/v1/billing/customers/search", {}, {"q": "a", "limit": 5}),
    }
    for name, (path, pp, q) in probes.items():
        try:
            r = api_other.get(path, path_params=pp, params=q)
        except Exception:
            continue
        if r.status == 200:
            found[name] = _first_id(r)
    if not any(found.values()):
        pytest.skip("salon B has no seeded records to attempt access on - "
                    "create a bill/service/appointment on the second QA salon")
    return found


def _victim_for(endpoint, victim_ids):
    path = endpoint.path
    if "billing/bills" in path:
        return victim_ids.get("bill")
    if path.startswith("/appointments"):
        return victim_ids.get("appointment")
    if "customer_memberships" in path:
        return victim_ids.get("membership")
    if "salon_services" in path:
        return victim_ids.get("service")
    if "billing/customers" in path:
        return victim_ids.get("customer")
    return None


@pytest.mark.parametrize("endpoint", UNSCOPED_READS, ids=ids(UNSCOPED_READS))
def test_cannot_read_another_salons_record(api, victim_ids, endpoint):
    victim = _victim_for(endpoint, victim_ids)
    if not victim:
        pytest.skip("no seeded record of this type on salon B")
    pp = {name: victim for name in endpoint.object_id_params}
    r = api.request(endpoint.method, endpoint.path, path_params=pp)
    assert r.status in DENIED, (
        f"IDOR - salon A read salon B's record via {endpoint.id} "
        f"(id={victim}) and got {r.status}" + r.explain())


@pytest.mark.destructive
@pytest.mark.parametrize("endpoint", UNSCOPED_WRITES, ids=ids(UNSCOPED_WRITES))
def test_cannot_write_another_salons_record(api, victim_ids, endpoint):
    victim = _victim_for(endpoint, victim_ids)
    if not victim:
        pytest.skip("no seeded record of this type on salon B")
    pp = {name: victim for name in endpoint.object_id_params}
    r = api.request(endpoint.method, endpoint.path, path_params=pp,
                    json=endpoint.example_body() or {})
    assert r.status in DENIED | {400, 422}, (
        f"IDOR - salon A wrote to salon B's record via {endpoint.id} "
        f"(id={victim}) and got {r.status}" + r.explain())


@pytest.mark.parametrize("endpoint", UNSCOPED_READS, ids=ids(UNSCOPED_READS))
def test_missing_record_is_404_not_500(api, endpoint):
    pp = {name: UNLIKELY_ID for name in endpoint.object_id_params}
    r = api.request(endpoint.method, endpoint.path, path_params=pp)
    assert r.status != 500, "missing record raised instead of 404" + r.explain()
    assert r.status in DENIED, f"expected 404, got {r.status}" + r.explain()


# --------------------------------------------------------------------------
# salon_id supplied as a query param - outside the SalonScoped concern entirely
# --------------------------------------------------------------------------
@pytest.mark.parametrize("endpoint", SALON_IN_QUERY, ids=ids(SALON_IN_QUERY))
def test_salon_id_query_param_is_authorized(api, other_salon_id, endpoint):
    """/salon_services takes salon_id in the query string, so the route pattern
    gives no protection at all. Ask for salon B's services with salon A's token."""
    r = api.get(endpoint.path, params={"salon_id": other_salon_id})
    assert r.status in DENIED, (
        f"TENANT LEAK - {endpoint.id}?salon_id={other_salon_id} returned "
        f"{r.status} to another salon's token" + r.explain())


@pytest.mark.parametrize("endpoint", SALON_IN_QUERY, ids=ids(SALON_IN_QUERY))
def test_missing_salon_id_query_param_is_handled(api, endpoint):
    r = api.get(endpoint.path)
    assert r.status != 500, "omitting salon_id crashed the endpoint" + r.explain()


def test_public_invoice_token_cannot_be_guessed(api_anon):
    """/invoices/:token is deliberately unauthenticated so a customer can open a
    shared link. That makes the token the entire access control."""
    for guess in ("1", "abc", "00000000-0000-0000-0000-000000000000", "../bills/1"):
        r = api_anon.raw("GET", f"{api_anon.base_url}/invoices/{guess}")
        assert r.status != 200, (
            f"guessable invoice token '{guess}' returned an invoice" + r.explain())
        assert r.status != 500, f"invoice token '{guess}' crashed" + r.explain()
