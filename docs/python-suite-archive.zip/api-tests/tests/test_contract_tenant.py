"""Multi-salon data isolation.

The dashboard only ever sends your own salon_id, so the UI can never produce
these requests. The backend's SalonScoped concern is the only thing standing
between salon A and salon B's revenue - and it is applied per controller, which
means it can be forgotten on exactly one of them.

Reads run by default. Writes are destructive by definition (if the bug exists,
this test modifies another salon's data) and are opt-in.
"""
import pytest

from lib.paramfill import dummy_path_params, sensible_query
from lib.spec_loader import load_endpoints, ids

pytestmark = [pytest.mark.contract, pytest.mark.tenant]

SCOPED = [e for e in load_endpoints() if e.salon_scoped]
SCOPED_READS = [e for e in SCOPED if e.is_safe]
SCOPED_WRITES = [e for e in SCOPED if not e.is_safe]

DENIED = {401, 403, 404}


@pytest.mark.parametrize("endpoint", SCOPED_READS, ids=ids(SCOPED_READS))
def test_cannot_read_another_salon(api, other_salon_id, endpoint):
    """Owner A's token against salon B's id must never return B's data."""
    r = api.request(endpoint.method, endpoint.path,
                    path_params=dummy_path_params(endpoint, other_salon_id),
                    params=sensible_query(endpoint))
    assert r.status in DENIED, (
        f"TENANT LEAK - {endpoint.module}: salon A read salon B "
        f"({other_salon_id}) and got {r.status}" + r.explain())


@pytest.mark.destructive
@pytest.mark.parametrize("endpoint", SCOPED_WRITES, ids=ids(SCOPED_WRITES))
def test_cannot_write_to_another_salon(api, other_salon_id, endpoint):
    r = api.request(endpoint.method, endpoint.path,
                    path_params=dummy_path_params(endpoint, other_salon_id),
                    params=sensible_query(endpoint),
                    json=endpoint.example_body() or {})
    assert r.status in DENIED | {400, 422}, (
        f"TENANT LEAK - {endpoint.module}: salon A wrote to salon B "
        f"({other_salon_id}) and got {r.status}" + r.explain())


@pytest.mark.parametrize("endpoint", SCOPED_READS, ids=ids(SCOPED_READS))
def test_nonexistent_salon_is_404_not_500(api, endpoint):
    """SalonScoped rescues RecordNotFound. A controller that forgot the concern
    raises instead, and the difference shows up as a 500."""
    r = api.request(endpoint.method, endpoint.path,
                    path_params=dummy_path_params(endpoint, 99999999),
                    params=sensible_query(endpoint))
    assert r.status != 500, "unhandled exception for a missing salon" + r.explain()
    assert r.status in DENIED, f"expected 401/404, got {r.status}" + r.explain()


def test_salon_id_is_not_taken_from_the_token_alone(api, other_salon_id):
    """Sanity check on the test itself: if the API ignored the URL and always
    used the token's salon, the tests above would pass for the wrong reason."""
    r = api.get("/salons/{salon_id}/dashboard/overview",
                path_params={"salon_id": other_salon_id}, params={"range": "month"})
    assert r.status != 200 or r.data is None, (
        "salon B's overview was served to salon A's token" + r.explain())
