"""End-to-end, the other direction: undo it, and try to break it.

test_journey_arithmetic.py proves that making a sale moves every report by the
right amount. This file proves the two harder things:

  REVERSAL   undoing a sale moves every report back by the right amount.
             A system that adds correctly and subtracts wrongly is worse than
             one that fails loudly, because the books look plausible.

  REFUSAL    an invalid action is refused AND leaves the books untouched.
             "It returned an error" is half a test; the other half is that
             nothing moved. Six invalid attempts are made between one pair of
             snapshots, so the assertion is simply: the books did not move.

BillsController#refund draws a distinction worth testing: a FULL refund unwinds
the sale and puts the goods back, a PARTIAL refund is only a price adjustment.
"""
from __future__ import annotations

import time
from decimal import Decimal as D

import pytest

from tests.journeys.lib_ledger import moved, report_delta, report_snapshot
from tests.journeys.lib_money import close, money

pytestmark = [pytest.mark.journey, pytest.mark.reconciliation, pytest.mark.destructive]

PRICE = D("600")


# ==========================================================================
# shared: raise and settle a bill we can then undo
# ==========================================================================
def _settle_one(api, salon_id, tag, price=PRICE, qty=1):
    """Returns the settled bill's id and its money, or a reason to skip."""
    svc = api.post("/salon_services", json={
        "salon_id": int(salon_id), "category": "APITEST Category",
        "custom_name": f"{tag} Service", "price": float(price),
        "duration_in_minutes": 30, "gender": "unisex", "active": True})
    if svc.status not in (200, 201):
        return None, f"could not create a service ({svc.status})"
    service_id = (svc.data or {}).get("id")

    cust = api.get("/salons/{salon_id}/salon_customer_profiles",
                   path_params={"salon_id": salon_id}, params={"per_page": 1})
    d = cust.data
    rows = d if isinstance(d, list) else (
        next((v for v in d.values() if isinstance(v, list)), []) if isinstance(d, dict) else [])
    if not rows:
        return None, "no customer on this salon to bill"

    created = api.post("/api/v1/billing/bills", json={
        "customer_id": rows[0].get("id"), "status": "draft",
        "items": [{"type": "service", "ref_id": service_id,
                   "name": f"{tag} Service", "qty": qty}]})
    if created.status not in (200, 201):
        return None, f"could not raise the bill ({created.status})"
    bid = (created.data or {}).get("id")

    detail = api.get("/api/v1/billing/bills/{id}", path_params={"id": bid})
    dd = detail.data or {}
    net = D(str(dd.get("net_payable") or 0))
    fin = api.post("/api/v1/billing/bills/{id}/finalize", path_params={"id": bid},
                   json={"payment": {"mode": "cash", "amount_paid": float(net)}})
    if fin.status not in (200, 201):
        return None, f"could not settle the bill ({fin.status}: {fin.error})"

    return {"bill_id": bid, "service_id": service_id, "net": net,
            "subtotal": D(str(dd.get("subtotal") or 0)),
            "tax": D(str(dd.get("tax_amount") or 0))}, None


# ==========================================================================
# A — a full refund must reverse every report
# ==========================================================================
@pytest.fixture(scope="module")
def refunded(api, salon_id, request):
    if not request.config.getoption("--run-destructive"):
        pytest.skip("destructive; re-run with --run-destructive")
    tag = f"JNEG-{time.strftime('%H%M%S')}"
    bill, problem = _settle_one(api, salon_id, tag)
    if problem:
        pytest.skip(problem)

    before = report_snapshot(api, salon_id, "today")
    r = api.patch("/api/v1/billing/bills/{id}/refund", path_params={"id": bill["bill_id"]},
                  json={"amount": float(bill["net"]), "reason": "APITEST full refund"})
    if r.status not in (200, 201):
        pytest.skip(f"refund returned {r.status}: {r.error}")
    after = report_snapshot(api, salon_id, "today")

    return {**bill, "tag": tag, "before": before, "after": after,
            "delta": report_delta(before, after)}


REVERSES = {
    "sales.total_revenue":            "net",
    "sales.service_revenue":          "net",
    "payments.total_collected":       "net",
    "services.total_revenue":         "net",
    "customers.total_spend_in_range": "net",
}


@pytest.mark.parametrize("field", sorted(REVERSES))
def test_full_refund_reverses_the_report(refunded, field):
    """A refunded sale must leave revenue where it started. If a report adds on
    the way in and does not subtract on the way out, its total drifts upward
    permanently and nothing on screen says why."""
    expected = -refunded["net"]
    got = refunded["delta"][field]
    assert close(got, expected), (
        f"\n  refunded {money(refunded['net'])} in full (bill {refunded['bill_id']})"
        f"{moved(refunded['before'], refunded['after'], field)}"
        f"\n    expected it to move by exactly {money(expected)}"
        f"\n  This is the regression test for the Sales/Payments revenue gap.")


def test_full_refund_is_recorded_as_refunded(refunded):
    got = refunded["delta"]["payments.failed_refunded_amount"]
    assert close(got, refunded["net"]), (
        f"\n  a full refund of {money(refunded['net'])} should appear as refunded"
        f"{moved(refunded['before'], refunded['after'], 'payments.failed_refunded_amount')}")


def test_full_refund_reduces_the_bill_count(refunded):
    got = refunded["delta"]["sales.bills_count"]
    assert close(got, D(-1), D(0)), (
        f"\n  a refunded bill should leave the settled count"
        f"{moved(refunded['before'], refunded['after'], 'sales.bills_count')}")


@pytest.mark.parametrize("field", ["expenses.total_expenses", "marketing.total_spend",
                                   "customers.total_customers", "staff_performance.total_staff"])
def test_refund_does_not_disturb_unrelated_reports(refunded, field):
    got = refunded["delta"][field]
    assert close(got, D(0)), (
        f"\n  refunding a bill moved a figure it should not touch"
        f"{moved(refunded['before'], refunded['after'], field)}")


def test_refund_leaves_profit_and_tax_consistent(refunded):
    """Whatever profit does on a refund, it must still reconcile with sales
    through the tax figure — the same invariant as on the way in."""
    a = refunded["after"]
    rebuilt = money(a["profit.gross_revenue"] + a["profit.tax_collected"])
    assert close(rebuilt, a["sales.total_revenue"], D("0.02")), (
        f"\n  after the refund: profit gross {money(a['profit.gross_revenue'])} + tax "
        f"{money(a['profit.tax_collected'])} = {rebuilt}, but sales revenue is "
        f"{money(a['sales.total_revenue'])}")


# ==========================================================================
# B — a partial refund is a price adjustment, not an unwind
# ==========================================================================
@pytest.fixture(scope="module")
def part_refunded(api, salon_id, request):
    if not request.config.getoption("--run-destructive"):
        pytest.skip("destructive; re-run with --run-destructive")
    tag = f"JNEGP-{time.strftime('%H%M%S')}"
    bill, problem = _settle_one(api, salon_id, tag)
    if problem:
        pytest.skip(problem)
    half = money(bill["net"] / 2)
    before = report_snapshot(api, salon_id, "today")
    r = api.patch("/api/v1/billing/bills/{id}/refund", path_params={"id": bill["bill_id"]},
                  json={"amount": float(half), "reason": "APITEST partial refund"})
    if r.status not in (200, 201):
        pytest.skip(f"partial refund returned {r.status}: {r.error}")
    after = report_snapshot(api, salon_id, "today")
    return {**bill, "half": half, "before": before, "after": after,
            "delta": report_delta(before, after)}


def test_partial_refund_moves_revenue_by_the_part_only(part_refunded):
    got = part_refunded["delta"]["sales.total_revenue"]
    expected = -part_refunded["half"]
    assert close(got, expected), (
        f"\n  refunded {money(part_refunded['half'])} of {money(part_refunded['net'])}"
        f"{moved(part_refunded['before'], part_refunded['after'], 'sales.total_revenue')}"
        f"\n    expected exactly {money(expected)}")


def test_partial_refund_keeps_the_bill_counted(part_refunded):
    """The controller is explicit: a part refund is a price adjustment, not an
    unwind of the sale. So the bill is still a sale."""
    got = part_refunded["delta"]["sales.bills_count"]
    assert close(got, D(0), D(0)), (
        f"\n  a partial refund removed the bill from the settled count"
        f"{moved(part_refunded['before'], part_refunded['after'], 'sales.bills_count')}"
        f"\n  BillsController#refund says only a full refund unwinds the sale.")


# ==========================================================================
# C — six invalid actions, one pair of snapshots, nothing may move
# ==========================================================================
@pytest.fixture(scope="module")
def refusals(api, api_other, other_salon_id, salon_id, request):
    if not request.config.getoption("--run-destructive"):
        pytest.skip("destructive; re-run with --run-destructive")
    tag = f"JREF-{time.strftime('%H%M%S')}"
    bill, problem = _settle_one(api, salon_id, tag)
    if problem:
        pytest.skip(problem)

    before = report_snapshot(api, salon_id, "today")
    attempts = {}

    attempts["settle an already-settled bill"] = api.post(
        "/api/v1/billing/bills/{id}/finalize", path_params={"id": bill["bill_id"]},
        json={"payment": {"mode": "cash", "amount_paid": float(bill["net"])}})

    attempts["refund more than was paid"] = api.patch(
        "/api/v1/billing/bills/{id}/refund", path_params={"id": bill["bill_id"]},
        json={"amount": float(bill["net"] * 10), "reason": "APITEST over-refund"})

    attempts["edit a settled bill"] = api.patch(
        "/api/v1/billing/bills/{id}", path_params={"id": bill["bill_id"]},
        json={"items": [], "discount": {"pct": 100}})

    attempts["set an appointment to an invented status"] = api.patch(
        "/appointments/{id}/status", path_params={"id": 99999999},
        json={"status": "teleported"})

    attempts["settle a bill that has no customer"] = None
    draft = api.post("/api/v1/billing/bills", json={
        "status": "draft",
        "items": [{"type": "service", "ref_id": bill["service_id"],
                   "name": f"{tag} orphan", "qty": 1}]})
    if draft.status in (200, 201):
        oid = (draft.data or {}).get("id")
        attempts["settle a bill that has no customer"] = api.post(
            "/api/v1/billing/bills/{id}/finalize", path_params={"id": oid},
            json={"payment": {"mode": "cash", "amount_paid": float(PRICE)}})

    attempts["read another salon's bill"] = api_other.get(
        "/api/v1/billing/bills/{id}", path_params={"id": bill["bill_id"]})

    after = report_snapshot(api, salon_id, "today")
    return {"tag": tag, "bill": bill, "attempts": attempts,
            "before": before, "after": after, "delta": report_delta(before, after)}


REFUSED_OK = {200, 201}


@pytest.mark.parametrize("attempt", [
    "settle an already-settled bill",
    "refund more than was paid",
    "edit a settled bill",
    "set an appointment to an invented status",
    "settle a bill that has no customer",
    "read another salon's bill",
])
def test_invalid_action_is_refused(refusals, attempt):
    r = refusals["attempts"].get(attempt)
    if r is None:
        pytest.skip(f"could not set up: {attempt}")
    assert r.status not in REFUSED_OK, (
        f"\n  '{attempt}' was ACCEPTED" + r.explain())
    assert r.status != 500, (
        f"\n  '{attempt}' crashed instead of being refused" + r.explain())


MONEY_AND_COUNTS = ["sales.total_revenue", "sales.bills_count", "payments.total_collected",
                    "payments.payments_count", "services.total_revenue",
                    "profit.gross_revenue", "customers.total_spend_in_range"]


@pytest.mark.parametrize("field", MONEY_AND_COUNTS)
def test_the_books_did_not_move_after_six_invalid_attempts(refusals, field):
    """The point of the whole file. Six things were attempted that should not
    have been allowed. Whatever each of them returned, the salon's numbers must
    be exactly where they were."""
    got = refusals["delta"][field]
    assert close(got, D(0)), (
        f"\n  six invalid actions were attempted and one of them changed the books"
        f"{moved(refusals['before'], refusals['after'], field)}"
        f"\n    attempts: {', '.join(refusals['attempts'])}")
