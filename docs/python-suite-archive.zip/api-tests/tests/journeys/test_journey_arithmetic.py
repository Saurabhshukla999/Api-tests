"""One journey, then every report checked for the EXACT number.

The original journey asked "did it appear?". This asks "by how much?" — and it
asks all ten reports, not two.

A bill of a known composition is raised and settled:

    subtotal  S = price x qty
    discount  D
    taxable   T = S - D
    tax       X = T x rate
    net       N = T + X

Every figure below is then asserted as an exact delta. Three kinds of check:

  MOVES   — the report must move by a precise amount
  STILL   — the report must NOT move at all (selling a service cannot change
            the Expenses report; that invariant is as valuable as the others)
  AGREES  — two reports must state the same number as each other

Each assertion is its own test, so a failure names the report and the field.
"""
from __future__ import annotations

from decimal import Decimal as D

import pytest

from tests.journeys.lib_ledger import moved, report_delta, report_snapshot
from tests.journeys.lib_money import close, money

pytestmark = [pytest.mark.journey, pytest.mark.reconciliation, pytest.mark.destructive]

PRICE = D("800")
QTY = 2
DISC_PCT = D("10")


@pytest.fixture(scope="module")
def journey(api, salon_id, request):
    """Raise and settle one bill of a known composition, snapshotting all ten
    reports before and after. Everything below reads this one pair."""
    if not request.config.getoption("--run-destructive"):
        pytest.skip("destructive; re-run with --run-destructive")

    import time
    tag = f"JARITH-{time.strftime('%H%M%S')}"

    svc = api.post("/salon_services", json={
        "salon_id": int(salon_id), "category": "APITEST Category",
        "custom_name": f"{tag} Service", "price": float(PRICE),
        "duration_in_minutes": 30, "gender": "unisex", "active": True})
    if svc.status not in (200, 201):
        pytest.skip(f"could not create the service: {svc.status}")
    service_id = (svc.data or {}).get("id")

    staff = api.get("/api/v1/billing/staff", params={"active": "true"})
    sd = staff.data
    staff_rows = sd if isinstance(sd, list) else (
        next((v for v in sd.values() if isinstance(v, list)), []) if isinstance(sd, dict) else [])
    staff_id = staff_rows[0].get("id") if staff_rows else None

    cust = api.get("/salons/{salon_id}/salon_customer_profiles",
                   path_params={"salon_id": salon_id}, params={"per_page": 1})
    d = cust.data
    rows = d if isinstance(d, list) else (next((v for v in d.values() if isinstance(v, list)), [])
                                          if isinstance(d, dict) else [])
    if not rows:
        pytest.skip("no customer to bill")
    customer_id = rows[0].get("id")

    before = report_snapshot(api, salon_id, "today")

    created = api.post("/api/v1/billing/bills", json={
        "customer_id": customer_id, "status": "draft",
        "items": [{k: v for k, v in {
            "type": "service", "ref_id": service_id, "name": f"{tag} Service",
            "qty": QTY, "staff_id": staff_id}.items() if v is not None}],
        "discount": {"pct": float(DISC_PCT)}})
    if created.status not in (200, 201):
        pytest.skip(f"could not raise the bill: {created.status} {created.error}")
    bill_id = (created.data or {}).get("id")

    detail = api.get("/api/v1/billing/bills/{id}", path_params={"id": bill_id})
    dd = detail.data or {}
    net = D(str(dd.get("net_payable") or 0))
    subtotal = D(str(dd.get("subtotal") or 0))
    tax = D(str(dd.get("tax_amount") or 0))
    discount = D(str(dd.get("discount_amount") or 0))

    fin = api.post("/api/v1/billing/bills/{id}/finalize", path_params={"id": bill_id},
                   json={"payment": {"mode": "cash", "amount_paid": float(net)}})
    if fin.status not in (200, 201):
        pytest.skip(f"could not settle the bill: {fin.status} {fin.error}")

    after = report_snapshot(api, salon_id, "today")

    return {"tag": tag, "bill_id": bill_id, "service_id": service_id,
            "staff_id": staff_id,
            "net": net, "subtotal": subtotal, "tax": tax, "discount": discount,
            "taxable": money(subtotal - discount),
            "before": before, "after": after,
            "delta": report_delta(before, after)}


def why(j, key, expected):
    return (f"\n  bill {j['bill_id']} ({j['tag']}): subtotal {money(j['subtotal'])} "
            f"- discount {money(j['discount'])} + tax {money(j['tax'])} = net {money(j['net'])}"
            f"{moved(j['before'], j['after'], key)}"
            f"\n    expected it to move by exactly {money(expected)}")


# ==========================================================================
# MOVES — these must change by a precise amount
# ==========================================================================
def _expect(j, name):
    """What each field should move by, derived from the bill."""
    return {
        "sales.total_revenue":            j["net"],
        "sales.bills_count":              D(1),
        "sales.service_revenue":          j["net"],
        "sales.product_revenue":          D(0),
        "sales.total_discount":           j["discount"],
        "payments.total_collected":       j["net"],
        "payments.payments_count":        D(1),
        "payments.failed_refunded_amount": D(0),
        "services.total_revenue":         j["net"],
        "services.services_sold":         D(QTY),
        "profit.gross_revenue":           j["taxable"],
        "profit.tax_collected":           j["tax"],
        "profit.total_discount":          j["discount"],
        "profit.net_profit":              j["taxable"],
        "profit.operating_expenses":      D(0),
        "profit.total_cost":              D(0),
        "customers.total_spend_in_range": j["net"],
        "staff_performance.total_service_revenue": j["net"],
        "customers.total_customers":      D(0),
        "expenses.total_expenses":        D(0),
        "expenses.expense_count":         D(0),
        "marketing.total_spend":          D(0),
        "marketing.attributed_revenue":   D(0),
        "marketing.total_campaigns":      D(0),
        "inventory.units_sold":           D(0),
        "inventory.sales_revenue":        D(0),
        "inventory.total_skus":           D(0),
        "appointments.total_appointments": D(0),
        "staff_performance.total_staff":  D(0),
        "staff_performance.active_staff": D(0),
    }[name]


MOVES = ["sales.total_revenue", "sales.bills_count", "sales.service_revenue",
         "sales.total_discount", "payments.total_collected", "payments.payments_count",
         "services.total_revenue", "services.services_sold",
         "profit.gross_revenue", "profit.tax_collected", "profit.total_discount",
         "profit.net_profit", "customers.total_spend_in_range",
         "staff_performance.total_service_revenue"]

STILL = ["sales.product_revenue", "payments.failed_refunded_amount",
         "profit.operating_expenses", "profit.total_cost",
         "expenses.total_expenses", "expenses.expense_count",
         "marketing.total_spend", "marketing.attributed_revenue",
         "marketing.total_campaigns", "inventory.units_sold",
         "inventory.sales_revenue", "inventory.total_skus",
         "appointments.total_appointments", "customers.total_customers",
         "staff_performance.total_staff", "staff_performance.active_staff"]


@pytest.mark.parametrize("field", MOVES)
def test_report_moved_by_exactly_the_right_amount(journey, field):
    expected = _expect(journey, field)
    got = journey["delta"][field]
    assert close(got, expected), why(journey, field, expected)


@pytest.mark.parametrize("field", STILL)
def test_report_did_not_move_at_all(journey, field):
    """Selling one service cannot change the Expenses report, the Marketing
    report, stock levels, or the number of customers. A figure that drifts here
    is being fed from somewhere it should not be."""
    got = journey["delta"][field]
    assert close(got, D(0)), (
        f"\n  a service-only bill moved a figure it should not touch"
        f"{moved(journey['before'], journey['after'], field)}"
        f"\n    expected no change at all")


# ==========================================================================
# AGREES — reports must state the same number as each other
# ==========================================================================
def test_sales_and_payments_agree_after_the_sale(journey):
    a = journey["after"]
    assert close(a["sales.total_revenue"], a["payments.total_collected"]), (
        f"\n  Reports · Sales says {money(a['sales.total_revenue'])}"
        f"\n  Reports · Payments says {money(a['payments.total_collected'])}"
        f"\n  difference {money(a['payments.total_collected'] - a['sales.total_revenue'])}")


def test_sales_and_services_agree_for_a_service_only_bill(journey):
    a = journey["after"]
    assert close(a["sales.service_revenue"], a["services.total_revenue"]), (
        f"\n  Sales · service revenue {money(a['sales.service_revenue'])} vs "
        f"Services · total revenue {money(a['services.total_revenue'])}")


def test_profit_plus_tax_equals_sales_revenue(journey):
    """Profit reports revenue net of tax; Sales reports it gross. They must
    reconcile through the tax figure, or one of them is wrong."""
    a = journey["after"]
    reconstructed = money(a["profit.gross_revenue"] + a["profit.tax_collected"])
    assert close(reconstructed, a["sales.total_revenue"], D("0.02")), (
        f"\n  Profit · gross revenue {money(a['profit.gross_revenue'])}"
        f"\n  + Profit · tax collected {money(a['profit.tax_collected'])}"
        f"\n  = {reconstructed}"
        f"\n  but Sales · total revenue = {money(a['sales.total_revenue'])}")


def test_sales_splits_into_service_and_product(journey):
    a = journey["after"]
    parts = money(a["sales.service_revenue"] + a["sales.product_revenue"])
    assert close(parts, a["sales.total_revenue"]), (
        f"\n  service {money(a['sales.service_revenue'])} + product "
        f"{money(a['sales.product_revenue'])} = {parts}, but total revenue is "
        f"{money(a['sales.total_revenue'])}")


def test_average_ticket_follows_revenue_and_count(journey):
    a = journey["after"]
    if a["sales.bills_count"] == 0:
        pytest.skip("no bills")
    expect = money(a["sales.total_revenue"] / a["sales.bills_count"])
    assert close(a["sales.average_ticket"], expect, D("0.5")), (
        f"\n  average ticket {money(a['sales.average_ticket'])} but "
        f"{money(a['sales.total_revenue'])} / {a['sales.bills_count']} = {expect}")


def test_a_bill_line_without_a_beautician_is_refused(api, journey):
    """A settled service with nobody attached earns no commission and never
    appears in Staff Performance. If the API accepts it silently, that revenue
    is invisible to the people whose pay depends on it."""
    r = api.post("/api/v1/billing/bills/calculate", json={
        "items": [{"type": "service", "ref_id": journey["service_id"],
                   "name": "no staff attached", "qty": 1}]})
    if r.status != 200:
        pytest.skip(f"calculate returned {r.status}")
    pytest.skip("informational: the API accepts a service line with no staff_id. "
                "Confirm with the team whether attribution should be mandatory — "
                "revenue booked this way is missing from Staff Performance and "
                "earns no commission.")


def test_top_performer_is_empty_when_nothing_is_attributed(journey):
    """Observed 27 Aug: with 9,250.51 of service revenue for the day and 0.00
    attributed to any beautician, the report still named a top performer.
    Naming the best of nothing is worse than naming nobody."""
    a = journey["after"]
    if a["staff_performance.total_service_revenue"] > 0:
        pytest.skip("revenue is attributed, so a top performer is legitimate")
    top = journey["after"].get("staff_performance.top_performer")
    assert not top, (
        f"\n  Staff Performance attributed {money(a['staff_performance.total_service_revenue'])} "
        f"of revenue to beauticians"
        f"\n  but still names '{top}' as top performer")
