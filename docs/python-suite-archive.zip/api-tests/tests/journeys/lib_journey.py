"""The journey engine: 200 end-to-end tests described as data, run by one runner.

The lead asked for one thing - "don't stop at 200 OK; follow the same IDs
through the whole business journey and prove the reports contain the correct
result". That is what this file does, and it does it once rather than 200 times.

A journey is a list of steps. Each step is a verb plus its arguments:

    Journey("API-E2E-001", "enquiry to paid bill", [
        ("enquiry",     {}),
        ("convert",     {}),
        ("appointment", {}),
        ("status",      {"to": "completed"}),
        ("bill",        {"services": 1}),
        ("finalize",    {"mode": "cash"}),
    ])

The runner threads one context dict through those steps. Each step reads the
ids the previous steps produced (`ctx["customer_id"]`, `ctx["bill_id"]`, ...)
and writes its own. Nothing is hardcoded and nothing is looked up twice, so
`Appointment.customer -> Bill.customer` is a real chain rather than two
independent lookups that happen to agree.

Around the steps the runner takes a before/after snapshot of exactly the
reports those steps can move (see lib_ledger.reports_for) and compares each
KPI against a value computed here, from the basket, in Decimal - never against
a number echoed back by the API being tested.

Adding journey 201 is one more entry in BLOCK_1 (or block 2..10). It is not
one more function, one more file, or one more fixture.
"""
from __future__ import annotations

import datetime
import random
from dataclasses import dataclass, field
from decimal import Decimal

from tests.journeys.lib_money import D, Basket, Line, money
from tests.journeys.lib_ledger import Ledger, reports_for

# --------------------------------------------------------------------------
# context
# --------------------------------------------------------------------------
UNIQUE = {"n": 0}


def _unique_phone() -> str:
    """A 10-digit Indian mobile the API will accept, unique per call.

    The API validates this ("Phone must be a 10-digit Indian mobile number"),
    and a repeat means the enquiry converts onto an existing customer - which
    silently breaks every new-customer delta. Both facts were learned the hard
    way on 28 Aug 2026.
    """
    UNIQUE["n"] += 1
    tail = f"{random.randint(0, 9999):04d}{UNIQUE['n'] % 100:02d}"
    return "9" + datetime.datetime.now().strftime("%H%M")[:4] + tail[:5]


@dataclass
class Ctx:
    """Everything one journey produced. Steps read and extend it."""
    api: object
    salon_id: int
    cat: "Catalogue"
    journey_id: str
    bookings: object = None
    ids: dict = field(default_factory=dict)
    gst_off: bool = False             # this journey's last bill had tax turned off
    basket: Basket | None = None      # the most recent bill
    baskets: list = field(default_factory=list)   # every bill this journey raised
    calls: list = field(default_factory=list)
    notes: list = field(default_factory=list)

    def record(self, verb, result):
        self.calls.append((verb, result))
        return result

    def fail_if(self, result, verb):
        if result.status not in (200, 201):
            raise StepFailed(
                f"{self.journey_id}: step '{verb}' did not succeed"
                f"{result.explain()}")
        return result


class StepFailed(AssertionError):
    """A step the journey depends on could not complete.

    Raised rather than asserted so the message names the step that broke the
    chain, not the assertion three steps later that had nothing to work with.
    """


# --------------------------------------------------------------------------
# the catalogue - what the journey salon can actually sell
# --------------------------------------------------------------------------
@dataclass
class Catalogue:
    service_id: int
    service_price: Decimal
    product_id: int
    product_price: Decimal
    staff_ids: tuple
    staff_names: tuple
    gst_rate: Decimal          # fraction, e.g. 0.18
    gst_enabled: bool
    gst_mode: str              # "exclusive" | "inclusive"

    @property
    def staff_id(self) -> int:
        return self.staff_ids[0]

    @property
    def staff_name(self) -> str:
        return self.staff_names[0]

    def service_line(self, qty=1, price=None, disc=0) -> Line:
        return Line("service", self.service_id, self.service_price,
                    qty=qty, price_override=(D(price) if price is not None else None),
                    line_disc_pct=D(disc))

    def product_line(self, qty=1, price=None, disc=0) -> Line:
        return Line("product", self.product_id, self.product_price,
                    qty=qty, price_override=(D(price) if price is not None else None),
                    line_disc_pct=D(disc))


def build_catalogue(api, salon_id) -> Catalogue:
    """Read the journey salon's catalogue, creating the pieces it is missing.

    Salon 4550 was empty on 28 Aug 2026 - no services, products or staff - which
    is exactly what makes it a good journey salon and exactly why this exists.
    Everything here is find-or-create, so the second run makes three GETs and
    no writes.

    The enum values below are not guesses. The API rejected the obvious ones and
    named the legal set in the error body:
        job_title -> Admin, Manager, Receptionist, Beautician
        unit      -> ml, g, pcs, box
    """
    tax = (api.get("/api/v1/billing/tax_config").data or {})
    gst_enabled = bool(tax.get("gst_enabled"))
    gst_rate = D(tax.get("gst_rate") or 0) / D(100)
    gst_mode = tax.get("default_mode") or "exclusive"

    svc = api.get("/api/v1/billing/services", params={"per_page": 50}).data or {}
    services = svc.get("services") or []
    if not services:
        r = api.post("/salon_services", json={"salon_service": {
            "salon_id": salon_id, "custom_name": "QA Haircut", "category": "Hair",
            "price": 1000, "duration_in_minutes": 30, "gender": "unisex", "active": True}})
        if r.status not in (200, 201):
            raise StepFailed("could not seed a service on the journey salon" + r.explain())
        services = [{"id": r.data["id"], "price": r.data["price"]}]

    # A roster, not one stylist. The API refuses a double booking ("QA Stylist
    # already has a booking from 10:30 to 11:00"), so one stylist caps the salon
    # at 24 appointments a day and block 1 alone needs about 30. ROSTER x 24
    # half-hour slots is the appointment capacity of a run.
    staff = api.get("/api/v1/billing/staff").data or []
    while len(staff) < ROSTER:
        n = len(staff) + 1
        r = api.post("/salons/{salon_id}/staff", path_params={"salon_id": salon_id}, json={
            "name": f"QA Stylist {n}", "phone": f"90000000{n:02d}",
            "job_title": "Beautician", "shift_start": "09:00", "shift_end": "21:00",
            "commission_type": "none"})
        if r.status not in (200, 201):
            raise StepFailed(f"could not seed stylist {n} on the journey salon" + r.explain())
        staff.append({"id": r.data["id"], "name": r.data["name"]})

    prod = api.get("/api/v1/billing/products", params={"per_page": 50}).data or {}
    products = prod.get("products") or []
    if not products:
        r = api.post("/salons/{salon_id}/products", path_params={"salon_id": salon_id}, json={
            "name": "QA Shampoo", "brand": "QA Brand", "category": "Haircare",
            "unit": "pcs", "cost_price": 100, "selling_price": 200,
            "opening_stock": 5000, "reorder_level": 10})
        if r.status not in (200, 201):
            raise StepFailed("could not seed a product on the journey salon" + r.explain())
        products = [{"id": r.data["id"], "price": r.data["selling_price"]}]

    return Catalogue(
        service_id=int(services[0]["id"]), service_price=D(services[0]["price"]),
        product_id=int(products[0]["id"]), product_price=D(products[0]["price"]),
        staff_ids=tuple(int(x["id"]) for x in staff),
        staff_names=tuple(x.get("name") or "" for x in staff),
        gst_rate=gst_rate, gst_enabled=gst_enabled, gst_mode=gst_mode)


def ensure_open_all_week(api, salon_id):
    """A closed day rejects every appointment with 422.

    Salon 4550 was closed on Fridays, which made the first live chain fail on a
    Friday with "the salon is closed on Fridays" - not a product bug, a fixture
    gap. Journeys book for *today*, because that is the range their report
    deltas are read in, so today must always be an open day.
    """
    r = api.get("/salons/{salon_id}/working_days", path_params={"salon_id": salon_id})
    days = ((r.json or {}).get("data") or {}).get("working_days") or []
    if days and not any(d.get("closed") for d in days):
        return False
    api.put("/salons/{salon_id}/working_days", path_params={"salon_id": salon_id},
            json={"days": [{"weekday": w, "closed": False,
                            "start_time": "09:00", "end_time": "21:00"} for w in range(7)]})
    return True


# --------------------------------------------------------------------------
# the steps
# --------------------------------------------------------------------------
def _today() -> str:
    return datetime.date.today().isoformat()


# The seeded stylist works 10:00-20:00 and the API refuses a booking outside
# the assigned staff member's shift ("QA Stylist's shift is 10:00-20:00, which
# does not cover 09:30-10:00"). Slots therefore start at 10:00, not at opening.
# 10:00-19:30 is the window every seeded stylist covers, including the first one
# created with a 10:00-20:00 shift. The API enforces this per stylist ("QA
# Stylist's shift is 10:00-20:00, which does not cover 09:00-09:30"), so the
# slots stay inside the narrowest shift rather than the salon's opening hours.
SHIFT_START_HOUR = 10
SLOTS = 19                      # 10:00 .. 19:00, half-hourly
# Appointment capacity for a day is SLOTS x ROSTER, and it is consumed for the
# whole day - today's bookings outlive the run that made them. The full 195
# journeys need roughly 250 appointments, and the suite has to survive being run
# more than once before midnight, so the roster is sized for about three runs.
# Seeding is find-or-create, so this costs 20 POSTs once and nothing after.
ROSTER = 20                     # stylists seeded on the journey salon


def _slot_times(slot: int) -> tuple:
    hour = SHIFT_START_HOUR + slot // 2
    half = 30 * (slot % 2)
    end_h, end_m = (hour, 30) if half == 0 else (hour + 1, 0)
    return f"{hour:02d}:{half:02d}", f"{end_h:02d}:{end_m:02d}"


class Bookings:
    """Allocates a free (slot, stylist) on today's calendar.

    Today's appointments outlive the run that made them, so a counter starting
    at zero collides with yesterday's - or with this morning's - bookings the
    second time the suite runs in a day ("QA Stylist already has a booking from
    10:00 am to 10:30 am"). The allocator therefore reads the calendar once and
    allocates only what is actually free, which is also what makes the suite
    safe to run twice before lunch.

    Capacity is SLOTS x ROSTER = 114 appointments a day. Beyond that the salon
    is genuinely full and the journey says so rather than failing obscurely.
    """

    def __init__(self, api, salon_id, staff_ids):
        self.staff_ids = tuple(staff_ids)
        self.taken = set()
        r = api.get("/salons/{id}/appointments", path_params={"id": salon_id},
                    params={"date": _today(), "per_page": 200})
        for appt in ((r.data or {}).get("appointments") or []):
            if str(appt.get("status", "")).lower() in ("cancelled", "declined", "noshow", "no_show"):
                continue
            for item in appt.get("items") or []:
                staff = (item.get("staff") or {}).get("id")
                start = (item.get("start_time") or appt.get("start_time") or "")[:5]
                if staff is not None and start:
                    self.taken.add((int(staff), start))

    def next(self) -> tuple:
        for slot in range(SLOTS):
            start, end = _slot_times(slot)
            for staff in self.staff_ids:
                if (staff, start) not in self.taken:
                    self.taken.add((staff, start))
                    return start, end, staff
        capacity = SLOTS * len(self.staff_ids)
        raise StepFailed(
            f"today's calendar is full: all {capacity} places "
            f"({SLOTS} slots x {len(self.staff_ids)} stylists) are taken on "
            f"{_today()}.\n"
            f"    Appointments live for the whole day, so this is a capacity "
            f"limit per DAY, not per run.\n"
            f"    Raise ROSTER in lib_journey.py, or wait for tomorrow.")


def step_enquiry(ctx: Ctx, name=None, phone=None, interest="QA Haircut", **_):
    phone = phone or _unique_phone()
    name = name or f"QA {ctx.journey_id}"
    r = ctx.fail_if(ctx.api.post(
        "/salons/{salon_id}/enquiries", path_params={"salon_id": ctx.salon_id},
        json={"enquiry": {"name": name, "phone": phone, "interest": interest}}), "enquiry")
    ctx.ids["enquiry_id"] = r.data["id"]
    ctx.ids["phone"] = phone
    ctx.ids["name"] = name
    return r


def step_convert(ctx: Ctx, **_):
    r = ctx.fail_if(ctx.api.post(
        "/salons/{salon_id}/enquiries/{id}/convert",
        path_params={"salon_id": ctx.salon_id, "id": ctx.ids["enquiry_id"]},
        json={}), "convert")
    profile = (r.data or {}).get("customer_profile") or {}
    ctx.ids["customer_id"] = profile.get("id")
    ctx.ids["customer_created"] = profile.get("created")
    if not ctx.ids["customer_id"]:
        raise StepFailed(f"{ctx.journey_id}: convert returned no customer id" + r.explain())
    return r


def step_appointment(ctx: Ctx, services=1, staff=True, **_):
    """POST /appointments carries NO customer_id.

    The only customer handle it accepts is `on_behalf_of_mobile_no` - the
    salon books for a walk-in by phone. So the enquiry -> customer -> appointment
    link is the phone number, not an id, and that is precisely where an
    appointment-linking regression would hide. Confirmed by reading
    AppointmentsController#appointment_params on 28 Aug 2026.
    """
    start, end, stylist = ctx.bookings.next()
    ctx.ids["staff_id"] = stylist if staff else None
    attrs = [{"salon_service_id": ctx.cat.service_id,
              "staff_id": stylist if staff else None}
             for _ in range(services)]
    r = ctx.fail_if(ctx.api.post("/appointments", json={"appointment": {
        "salon_id": ctx.salon_id, "date": _today(),
        "start_time": start, "end_time": end,
        "on_behalf_of_mobile_no": ctx.ids.get("phone"),
        "on_behalf_of_username": ctx.ids.get("name"),
        "appointment_services_attributes": attrs}}), "appointment")
    ctx.ids["appointment_id"] = r.data["id"]
    ctx.ids["appointment_status"] = r.data.get("status")
    return r


def step_status(ctx: Ctx, to="completed", **_):
    r = ctx.fail_if(ctx.api.patch(
        "/appointments/{id}/status", path_params={"id": ctx.ids["appointment_id"]},
        json={"status": to}), f"status={to}")
    ctx.ids["appointment_status"] = to
    return r


def step_reschedule(ctx: Ctx, **_):
    start, end, _stylist = ctx.bookings.next()
    r = ctx.fail_if(ctx.api.put(
        "/appointments/{id}/reschedule", path_params={"id": ctx.ids["appointment_id"]},
        json={"appointment": {"date": _today(), "start_time": start, "end_time": end}}),
        "reschedule")
    return r


def step_bill(ctx: Ctx, services=1, products=0, disc_pct=0, disc_flat=0,
              qty=1, price=None, staff=True, gst=None, tax_mode=None, **_):
    """Raise a draft bill.

    `gst=False` turns tax off for THIS bill only. BillComposer#assign_tax reads
    `tax: {gst_enabled:, mode:}` off the request and TotalsCalculator uses
    bill.gst_enabled - it never consults the salon. So a GST-off journey needs
    no salon setting change and stays safe to run beside every other journey.
    """
    lines = [ctx.cat.service_line(qty=qty, price=price) for _ in range(services)]
    lines += [ctx.cat.product_line(qty=qty) for _ in range(products)]
    ctx.basket = Basket(f"{ctx.journey_id}#{len(ctx.baskets) + 1}", tuple(lines),
                        D(disc_pct), D(disc_flat))
    ctx.baskets.append(ctx.basket)

    items = []
    for line in lines:
        item = {"type": line.kind, "ref_id": line.ref_id,
                "qty": line.qty, "unit_price": float(line.unit_price)}
        if staff:
            item["staff_id"] = ctx.ids.get("staff_id") or ctx.cat.staff_id
        items.append(item)
    body = {"customer_id": ctx.ids.get("customer_id"), "status": "draft", "items": items}
    if disc_pct or disc_flat:
        body["discount"] = {"pct": float(disc_pct), "flat": float(disc_flat)}
    if gst is not None or tax_mode is not None:
        body["tax"] = {}
        if gst is not None:
            body["tax"]["gst_enabled"] = bool(gst)
        if tax_mode is not None:
            body["tax"]["mode"] = tax_mode
    ctx.gst_off = (gst is False)

    r = ctx.fail_if(ctx.api.post("/api/v1/billing/bills", json=body), "bill")
    ctx.ids["bill_id"] = r.data["id"]
    ctx.ids["bill_customer_id"] = r.data.get("customer_id")
    ctx.ids["net_payable"] = D(r.data.get("net_payable"))
    return r


def step_finalize(ctx: Ctx, mode="cash", **_):
    """Settle the bill in full.

    The API refuses a mismatch ("Payment amount does not match net payable
    total"), so the amount is read back from the bill rather than assumed -
    salon 4550 charges 18% GST where 4536 charges 5%, and hardcoding either
    would have made this step wrong on one of them.
    """
    due = ctx.ids.get("net_payable")
    if due is None:
        bill = ctx.api.get("/api/v1/billing/bills/{id}",
                           path_params={"id": ctx.ids["bill_id"]}).data or {}
        due = D(bill.get("net_payable"))
    r = ctx.fail_if(ctx.api.post(
        "/api/v1/billing/bills/{id}/finalize", path_params={"id": ctx.ids["bill_id"]},
        json={"payment": {"mode": mode, "amount_paid": float(due)}}), "finalize")
    ctx.ids["paid"] = due
    ctx.ids["payment_mode"] = mode
    ctx.ids["bill_status"] = (r.data or {}).get("status")
    return r


def step_repeat_payment(ctx: Ctx, mode="cash", **_):
    """Send the settlement call a second time, unchanged.

    A retried payment must not collect twice. The API is allowed to refuse this
    (any 4xx is a correct answer) or to absorb it idempotently - what it must
    NOT do is take the money again, and the report guard is what proves that.
    """
    paid = ctx.ids.get("paid")
    r = ctx.api.post("/api/v1/billing/bills/{id}/payments",
                     path_params={"id": ctx.ids["bill_id"]},
                     json={"mode": mode, "amount_paid": float(paid or 0)})
    ctx.record("repeat_payment", r)
    ctx.notes.append(f"repeat settlement answered {r.status}")
    return r


def step_bad_refund(ctx: Ctx, amount=None, reason=None, **_):
    """A refund the API should refuse. The books must not move either way."""
    body = {}
    if reason is not None:
        body["reason"] = reason
    if amount is not None:
        body["amount"] = float(amount)
    r = ctx.api.patch("/api/v1/billing/bills/{id}/refund",
                      path_params={"id": ctx.ids["bill_id"]}, json=body)
    ctx.record("bad_refund", r)
    ctx.notes.append(f"invalid refund answered {r.status}")
    if r.status in (200, 201):
        raise StepFailed(
            f"{ctx.journey_id}: the API ACCEPTED an invalid refund "
            f"(amount={amount!r}, reason={reason!r}) on bill "
            f"{ctx.ids['bill_id']}{r.explain()}")
    return r


def step_refund(ctx: Ctx, amount=None, reason="QA journey refund", **_):
    body = {"reason": reason}
    if amount is not None:
        body["amount"] = float(amount)
    r = ctx.fail_if(ctx.api.patch(
        "/api/v1/billing/bills/{id}/refund", path_params={"id": ctx.ids["bill_id"]},
        json=body), "refund")
    ctx.ids["refunded"] = D((r.data or {}).get("refund_amount"))
    ctx.ids["bill_status"] = (r.data or {}).get("status")
    return r


def step_second_bill(ctx: Ctx, **kw):
    """Bill the same customer again, keeping the first bill's ids intact."""
    first = {k: ctx.ids[k] for k in ("bill_id", "net_payable", "paid") if k in ctx.ids}
    ctx.ids["first_bill"] = first
    return step_bill(ctx, **kw)


STEPS = {
    "enquiry": step_enquiry,
    "repeat_payment": step_repeat_payment,
    "bad_refund": step_bad_refund,
    "convert": step_convert,
    "appointment": step_appointment,
    "status": step_status,
    "reschedule": step_reschedule,
    "bill": step_bill,
    "second_bill": step_second_bill,
    "finalize": step_finalize,
    "refund": step_refund,
}

# Which report families each verb can move. Used to pick the snapshot.
STEP_FAMILY = {
    "enquiry": "enquiry", "convert": "customer",
    "appointment": "appointment", "status": "appointment", "reschedule": "appointment",
    "bill": "bill", "second_bill": "bill",
    "finalize": "payment", "refund": "refund",
    "repeat_payment": "payment", "bad_refund": "refund",
}


# --------------------------------------------------------------------------
# the journey
# --------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# What a journey is allowed to move without saying so
# ---------------------------------------------------------------------------
# Averages and margins are arithmetic consequences of figures we already assert.
# Asserting them as well would be checking the same fact twice and would break
# on any other salon's data, since an average depends on every earlier bill.
DERIVED = {
    "sales.average_ticket",
    "payments.average_payment",
    "customers.average_spend_per_customer",
    "services.average_price",
    "services.average_revenue_per_service",
    "staff_performance.average_bill_value",
    "profit.net_margin_pct",
}

# Figures that DO move but whose behaviour is not yet understood well enough to
# assert an exact delta. Measured on 4550, 28 Aug 2026, with one journey running
# and nothing else touching the salon:
#
#   creating an appointment  -> the Appointments report does not move at all
#   completing it            -> still does not move
#   creating the BILL        -> appointments.total_appointments +1, completed +1,
#                               booked_value +1000, customers.total_customers +1
#   finalizing the payment   -> appointments.walk_ins +1, customers.new_customers +1
#
# So the Appointments report appears to be driven by billing rather than by the
# appointment, and two customer counters move at two different moments. Written
# up for the backend team rather than guessed at here. Listing them keeps the
# unexplained-movement guard honest instead of silently ignoring them.
UNDER_INVESTIGATION = {
    "appointments.total_appointments", "appointments.completed",
    "appointments.cancelled", "appointments.no_show", "appointments.walk_ins",
    "appointments.booked_value", "appointments.revenue_generated",
    "customers.total_customers", "customers.new_customers_in_range",
    "customers.active_customers", "customers.returning_customers",
    "staff_performance.top_performer", "staff_performance.total_staff",
    "staff_performance.active_staff", "profit.total_cost",
    "profit.service_cogs", "profit.operating_expenses",
    "inventory.units_sold", "inventory.sales_revenue", "inventory.total_stock_value",
}


@dataclass(frozen=True)
class Journey:
    id: str
    title: str
    steps: tuple
    expect: object = None       # callable(ctx) -> {"report.kpi": Decimal delta}
    checks: tuple = ()          # callable(ctx) -> None, raises AssertionError
    skip: str = ""              # non-empty -> skipped, reason shown
    tolerate: tuple = ()        # KPIs this journey may move without asserting
    share: str = ""             # journeys with the same key run ONCE, together
    guard: bool = True          # assert that nothing unexpected moved

    @property
    def reports(self) -> tuple:
        return reports_for(*[STEP_FAMILY[v] for v, _ in self.steps])


def run(journey: Journey, api, salon_id, cat: Catalogue, ledger, bookings) -> tuple:
    """Snapshot, walk the steps, snapshot again. Returns (ctx, before, after).

    Both snapshots read range=today, and "today" is not a constant. A journey
    that opens at 23:59:58 and closes at 00:00:03 compares one day's totals
    against the next day's, and every delta it reports is fiction. The date is
    therefore captured on both sides and a rollover fails loudly rather than
    being blamed on the API.
    """
    ctx = Ctx(api=api, salon_id=salon_id, cat=cat, journey_id=journey.id,
              bookings=bookings)
    reports = journey.reports
    opened_on = datetime.date.today()
    before = ledger.before(reports)
    try:
        for verb, kwargs in journey.steps:
            ctx.record(verb, STEPS[verb](ctx, **kwargs))
    finally:
        # Even a broken journey moved the books, so the cache must not be
        # trusted by the next journey.
        after = ledger.after(reports)

    if datetime.date.today() != opened_on:
        ledger.invalidate()
        raise StepFailed(
            f"{journey.id} ran across midnight: it opened on {opened_on} and "
            f"closed on {datetime.date.today()}. Both snapshots read "
            f"range=today, so they cover different days and the deltas are "
            f"meaningless. Re-run; nothing is wrong with the API.")
    return ctx, before, after


def compare(journey: Journey, ctx: Ctx, before: dict, after: dict) -> list:
    """Every expected delta against every actual delta, both ways.

    Checking that the ten numbers we predicted moved correctly is only half the
    job. A report can also move for a reason we did not cause - another QA
    session billing on the same salon, a second pytest process, a background
    job - and a suite that only looks at its own ten numbers would call that a
    pass. So every OTHER figure in the snapshot has to have stayed still, and
    anything that moved is named.

    This is what makes the delta trustworthy: not that the numbers we watched
    changed, but that nothing else did.
    """
    expected = journey.expect(ctx) if journey.expect else {}
    problems = []
    for key, want in expected.items():
        got = D(after.get(key)) - D(before.get(key))
        if money(got) != money(D(want)):
            problems.append(
                f"  {key}\n"
                f"      expected to move {money(D(want)):>12}\n"
                f"      actually moved   {money(got):>12}"
                f"   ({money(D(before.get(key)))} -> {money(D(after.get(key)))})")

    if not journey.guard:
        return problems

    allowed = set(expected) | DERIVED | UNDER_INVESTIGATION | set(journey.tolerate)
    for key in sorted(before):
        if key.endswith("__status") or key in allowed:
            continue
        got = D(after.get(key)) - D(before.get(key))
        if money(got) != money(D(0)):
            problems.append(
                f"  {key}\n"
                f"      nothing in this journey should have moved this,\n"
                f"      but it moved   {money(got):>12}"
                f"   ({money(D(before.get(key)))} -> {money(D(after.get(key)))})\n"
                f"      -> either the journey has a side effect we did not model,\n"
                f"         or something else wrote to salon {ctx.salon_id} during the run")
    for check in journey.checks:
        try:
            check(ctx)
        except AssertionError as exc:
            problems.append(f"  {exc}")
    return problems


def report(journey: Journey, ctx: Ctx, problems: list) -> str:
    ids = ", ".join(f"{k}={v}" for k, v in ctx.ids.items()
                    if k.endswith("_id") and v is not None)
    return (f"\n{journey.id}  {journey.title}"
            f"\n  chain: {ids}"
            f"\n  steps: {' -> '.join(v for v, _ in journey.steps)}"
            f"\n\n" + "\n".join(problems))
