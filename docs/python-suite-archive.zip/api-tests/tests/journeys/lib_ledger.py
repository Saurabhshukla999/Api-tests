"""Reads the same number off every surface that reports it.

Revenue for a date range is stated in at least six places. They are computed by
different queries, so they can drift - and when they drift, the owner sees one
number on the dashboard and a different one in the report, with no way to tell
which is true.

`snapshot()` reads them all. `delta()` says what moved. A test then asserts the
movement is exactly what the action should have caused - not merely that
something moved.

Field paths confirmed against the live API on 27 Aug 2026.
"""
from __future__ import annotations

from decimal import Decimal as D

from tests.journeys.lib_money import money


def _n(x) -> D:
    try:
        return D(str(x if x is not None else 0))
    except Exception:
        return D(0)


def _kpi(data, *path):
    node = data or {}
    for key in path:
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    return node


# Every surface that states money or a bill count for a date range.
SURFACES = {
    "dashboard.revenue":        "Dashboard · Overview · Revenue card",
    "dashboard.appointments":   "Dashboard · Overview · Appointments card",
    "sales.total_revenue":      "Reports · Sales · Total revenue",
    "sales.bills_count":        "Reports · Sales · Bills count",
    "sales.average_ticket":     "Reports · Sales · Average ticket",
    "sales.rows_total":         "Reports · Sales · rows (status=paid)",
    "sales.rows_unfiltered":    "Reports · Sales · rows (no filter)",
    "payments.total_collected": "Reports · Payments · Total collected",
    "payments.count":           "Reports · Payments · Payments count",
    "billing.today_bills":      "Billing · Summary · today.bills",
    "billing.today_collected":  "Billing · Summary · today.collected",
    "billing.paid_count":       "Billing · Summary · by_status.paid",
    "bills.list_total":         "Billing · Bills list · meta.total_count",
}


def snapshot(api, salon_id, rng: str = "today") -> dict:
    """Seven requests. Returns a flat dict of every reported figure."""
    s: dict[str, D] = {}

    r = api.get("/salons/{salon_id}/dashboard/overview", path_params={"salon_id": salon_id},
                params={"range": rng, "refresh": "true"})
    s["dashboard.revenue"] = _n(_kpi(r.data, "kpis", "revenue", "value"))
    s["dashboard.appointments"] = _n(_kpi(r.data, "kpis", "appointments", "value"))

    r = api.get("/salons/{salon_id}/reports/sales/summary", path_params={"salon_id": salon_id},
                params={"range": rng})
    s["sales.total_revenue"] = _n(_kpi(r.data, "kpis", "total_revenue", "value"))
    s["sales.bills_count"] = _n(_kpi(r.data, "kpis", "bills_count", "value"))
    s["sales.average_ticket"] = _n(_kpi(r.data, "kpis", "average_ticket", "value"))

    # meta sits INSIDE data on the report endpoints, not at the top level.
    r = api.get("/salons/{salon_id}/reports/sales/rows", path_params={"salon_id": salon_id},
                params={"range": rng, "page": 1, "per_page": 1, "status": "paid"})
    meta = ((r.data or {}).get("meta") or {}) if isinstance(r.data, dict) else {}
    s["sales.rows_total"] = _n(meta.get("total") or meta.get("total_count"))

    # the same table with no status filter - what the owner actually sees first
    r = api.get("/salons/{salon_id}/reports/sales/rows", path_params={"salon_id": salon_id},
                params={"range": rng, "page": 1, "per_page": 1})
    meta = ((r.data or {}).get("meta") or {}) if isinstance(r.data, dict) else {}
    s["sales.rows_unfiltered"] = _n(meta.get("total") or meta.get("total_count"))

    r = api.get("/salons/{salon_id}/reports/payments/summary", path_params={"salon_id": salon_id},
                params={"range": rng})
    s["payments.total_collected"] = _n(_kpi(r.data, "kpis", "total_collected", "value"))
    s["payments.count"] = _n(_kpi(r.data, "kpis", "payments_count", "value"))

    r = api.get("/api/v1/billing/summary", params={"range": "today"})
    s["billing.today_bills"] = _n(_kpi(r.data, "today", "bills"))
    s["billing.today_collected"] = _n(_kpi(r.data, "today", "collected"))
    s["billing.paid_count"] = _n(_kpi(r.data, "today", "by_status", "paid"))
    s["billing.by_mode"] = _kpi(r.data, "today", "by_mode") or {}

    r = api.get("/api/v1/billing/bills", params={"per_page": 1})
    meta = (r.json or {}).get("meta") or {}
    s["bills.list_total"] = _n(meta.get("total_count") or meta.get("total"))
    return s


def delta(before: dict, after: dict) -> dict:
    out = {}
    for k in SURFACES:
        out[k] = money(_n(after.get(k)) - _n(before.get(k)))
    return out


def describe(before, after, key) -> str:
    return (f"\n  {SURFACES.get(key, key)}"
            f"\n    before {money(_n(before.get(key)))}"
            f"  →  after {money(_n(after.get(key)))}"
            f"  (moved {money(_n(after.get(key)) - _n(before.get(key)))})")


# ==========================================================================
# every report's summary, in one flat dict
# ==========================================================================
# Field names confirmed against the live API on 27 Aug 2026. Each entry is
# report -> the KPI keys worth asserting a delta on.
REPORT_KPIS = {
    "sales":            ["total_revenue", "bills_count", "average_ticket",
                         "service_revenue", "product_revenue", "total_discount"],
    "appointments":     ["total_appointments", "completed", "cancelled", "no_show",
                         "walk_ins", "revenue_generated", "booked_value"],
    "services":         ["total_revenue", "services_sold", "average_price",
                         "average_revenue_per_service"],
    "staff_performance":["total_staff", "active_staff", "total_service_revenue",
                         "average_bill_value", "total_commission", "top_performer"],
    "expenses":         ["total_expenses", "expense_count", "avg_daily_expense",
                         "pending_amount"],
    "customers":        ["total_customers", "new_customers_in_range", "new_customers",
                         "returning_customers", "active_customers",
                         "average_spend_per_customer", "total_spend_in_range"],
    "inventory":        ["total_skus", "low_stock_items", "out_of_stock_items",
                         "units_sold", "sales_revenue", "total_stock_value"],
    "profit":           ["gross_revenue", "operating_expenses", "service_cogs",
                         "total_cost", "tax_collected", "total_discount",
                         "net_profit", "net_margin_pct"],
    "marketing":        ["total_campaigns", "total_spend", "messages_sent",
                         "total_bookings", "attributed_revenue"],
    "payments":         ["total_collected", "payments_count", "average_payment",
                         "failed_refunded_amount"],
}


ALL_REPORTS = tuple(REPORT_KPIS)

# Which reports a step can possibly move. A journey declares the steps it
# performs; the engine snapshots the union, and nothing else. Reading a report
# a journey cannot touch costs two requests and proves nothing.
AFFECTED_BY = {
    "enquiry":     (),
    "customer":    ("customers",),
    "appointment": ("appointments",),
    "attendance":  ("staff_performance",),
    "expense":     ("expenses", "profit"),
    "product_line": ("inventory", "sales", "profit"),
    "bill":        ("sales", "services", "staff_performance", "profit", "customers"),
    "payment":     ("payments", "sales", "profit", "customers"),
    "refund":      ("payments", "sales", "services", "staff_performance",
                    "profit", "customers", "inventory"),
}


def reports_for(*steps) -> tuple:
    """The reports a journey made of these steps can move, in a stable order."""
    wanted = set()
    for step in steps:
        wanted |= set(AFFECTED_BY.get(step, ()))
    return tuple(r for r in ALL_REPORTS if r in wanted)


def report_snapshot(api, salon_id, rng: str = "today", only=None) -> dict:
    """One request per report. Keys are 'report.kpi'.

    `only` restricts the read to the named reports; the default reads all ten.
    """
    out: dict[str, D] = {}
    wanted = REPORT_KPIS if only is None else {
        r: REPORT_KPIS[r] for r in only if r in REPORT_KPIS}
    for report, keys in wanted.items():
        r = api.get("/salons/{salon_id}/reports/{report_key}/summary"
                    .replace("{report_key}", report),
                    path_params={"salon_id": salon_id}, params={"range": rng})
        kpis = (r.data or {}).get("kpis") or {} if r.status == 200 else {}
        for key in keys:
            node = kpis.get(key)
            val = node.get("value") if isinstance(node, dict) else node
            out[f"{report}.{key}"] = _n(val)
        out[f"{report}.__status"] = D(r.status)
    return out


def report_delta(before: dict, after: dict) -> dict:
    return {k: money(_n(after.get(k)) - _n(before.get(k)))
            for k in before if not k.endswith("__status")}


def moved(before, after, key) -> str:
    return (f"\n  {key}"
            f"\n    before {money(_n(before.get(key)))}"
            f"  →  after {money(_n(after.get(key)))}"
            f"  (moved {money(_n(after.get(key)) - _n(before.get(key)))})")


# ==========================================================================
# Ledger - the snapshot cache that makes a serial suite affordable
# ==========================================================================
class Ledger:
    """Holds report state across journeys so each report is read once, not twice.

    The suite runs journeys serially against one salon, because a journey
    asserts an exact delta and eight parallel journeys would each see the other
    seven's money. Serial execution has a compensating gift: nothing else moves
    the books between journey N finishing and journey N+1 starting, so N's
    "after" snapshot IS N+1's "before" snapshot.

    Combined with `only=`, a journey that touches five reports costs five
    requests instead of twenty.

    The one invariant that keeps this honest: after any mutation, ONLY the
    reports actually re-read are current. `after()` therefore drops every
    report it did not read. A journey that under-declares its affected reports
    gets a stale cache, not a silent pass - so when in doubt, declare more.
    """

    def __init__(self, api, salon_id, rng: str = "today"):
        self.api, self.salon_id, self.rng = api, salon_id, rng
        self._state: dict[str, D] = {}
        self._fresh: set[str] = set()
        self.reads = 0

    def _read(self, reports) -> dict:
        reports = tuple(reports)
        if not reports:
            return {}
        snap = report_snapshot(self.api, self.salon_id, self.rng, only=reports)
        self.reads += len(reports)
        self._state.update(snap)
        self._fresh |= set(reports)
        return snap

    def before(self, reports) -> dict:
        """State prior to the action. Served from cache where it is current."""
        reports = tuple(reports)
        stale = [r for r in reports if r not in self._fresh]
        self._read(stale)
        return {k: v for k, v in self._state.items()
                if k.split(".", 1)[0] in set(reports)}

    def after(self, reports) -> dict:
        """State following the action. Everything unread is now stale."""
        reports = tuple(reports)
        self._fresh -= (self._fresh - set(reports))
        return self._read(reports)

    def invalidate(self):
        """Call when something outside the journeys may have moved the books -
        a failed journey, a manual poke at the QA salon, a run resuming."""
        self._fresh.clear()
