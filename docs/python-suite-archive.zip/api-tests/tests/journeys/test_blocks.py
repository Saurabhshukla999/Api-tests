"""API-E2E blocks 1-3, run by the engine. One test per journey id, as the lead listed them.

Journeys marked with the same `share` key run ONCE and every id in that group
asserts against the same pair of snapshots. That is how "full payment -> verify
Sales", "-> verify Payments", "-> verify Customer spend" and their four siblings
stay seven traceable test ids while costing one settlement instead of seven.
"""
import pytest

from tests.journeys.lib_journey import (
    Bookings, Ledger, build_catalogue, ensure_open_all_week, run, compare, report)
from tests.journeys.block1_cases import BLOCK_1
from tests.journeys.block2_cases import BLOCK_2
from tests.journeys.block3_cases import BLOCK_3

pytestmark = [pytest.mark.journey, pytest.mark.destructive, pytest.mark.P1]

JOURNEYS = BLOCK_1 + BLOCK_2 + BLOCK_3


@pytest.fixture(scope="session")
def catalogue(api_journey, journey_salon_id):
    """One roster, one service, one product - created only if absent."""
    ensure_open_all_week(api_journey, journey_salon_id)
    return build_catalogue(api_journey, journey_salon_id)


@pytest.fixture(scope="session")
def bookings(api_journey, journey_salon_id, catalogue):
    """Reads today's calendar once, then hands out only free slots."""
    return Bookings(api_journey, journey_salon_id, catalogue.staff_ids)


@pytest.fixture(scope="session")
def ledger(api_journey, journey_salon_id):
    """Shared across every block: journey N's 'after' is N+1's 'before'."""
    return Ledger(api_journey, journey_salon_id, "today")


@pytest.fixture(scope="session")
def shared_runs():
    """One completed run per `share` key, reused by every id in that group."""
    return {}


@pytest.mark.parametrize("journey", JOURNEYS, ids=[j.id for j in JOURNEYS])
def test_journey(api_journey, journey_salon_id, catalogue, ledger, bookings,
                 shared_runs, journey):
    if journey.skip:
        pytest.skip(journey.skip)

    if journey.share:
        if journey.share not in shared_runs:
            shared_runs[journey.share] = run(
                journey, api_journey, journey_salon_id, catalogue, ledger, bookings)
        ctx, before, after = shared_runs[journey.share]
    else:
        ctx, before, after = run(
            journey, api_journey, journey_salon_id, catalogue, ledger, bookings)

    problems = compare(journey, ctx, before, after)
    assert not problems, report(journey, ctx, problems)
