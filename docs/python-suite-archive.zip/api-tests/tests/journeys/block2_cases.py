"""Block 2 - API-E2E-076 .. 100. Payments and settlement.

Ten of these need two payments against one bill - an advance and then the
balance. That is the partial-payment feature, which is switched off in the Nearz
frontend, so they are written and skip-marked rather than dropped: turning them
on is deleting one `skip=` when the feature comes back.

079-085 are the lead's list asking seven questions of one event ("full payment
-> verify Sales", "-> verify Payments", "-> verify Customer spend", ...). They
share a single journey run: one settlement, seven test ids, seven assertions,
about sixteen HTTP requests instead of a hundred and twelve. 079 carries the
full expectation and the unexplained-movement guard; 080-085 each state their
own KPI against the same snapshots.
"""
from __future__ import annotations

from tests.journeys.lib_journey import Journey
from tests.journeys.lib_money import D
from tests.journeys.block1_cases import (
    CHAIN, PAY, settled, settled_then_refunded, _gross, _rate, _last,
    _refunded, _taxable, _tax, _kind_gross, _discount,
    bill_is_paid, bill_is_refunded, bill_belongs_to_converted_customer)

PARTIAL = "partial payments are switched off in the frontend"

# --------------------------------------------------------------------------
# 079-085: one settlement, seven questions
# --------------------------------------------------------------------------
SETTLE = tuple(CHAIN + PAY)


def one(key, value):
    """A single-KPI expectation, for a journey sharing another's run."""
    return lambda ctx: {key: value(ctx)}


def bills_settled_unchanged(ctx):
    """085: a bill settled in one payment must not double-count as settled."""
    return {"sales.bills_count": D(1), "payments.payments_count": D(1)}


# --------------------------------------------------------------------------
# checks
# --------------------------------------------------------------------------
def no_second_collection(ctx):
    """097/098: the retried settlement must not have taken the money twice."""
    r = ctx.api.get("/api/v1/billing/bills/{id}", path_params={"id": ctx.ids["bill_id"]})
    bill = r.data or {}
    paid, due = D(bill.get("amount_paid")), D(bill.get("net_payable"))
    assert paid == due, (
        f"bill {ctx.ids['bill_id']} was settled once and the call retried, but "
        f"amount_paid is {paid} against a net payable of {due} - "
        f"the retry collected again")
    assert D(bill.get("amount_due")) == D(0), (
        f"bill {ctx.ids['bill_id']} shows {bill.get('amount_due')} still due "
        f"after a full settlement")


def ledger_agrees_with_the_bill(ctx):
    """099: the Payments report row must match the bill it came from."""
    bill = (ctx.api.get("/api/v1/billing/bills/{id}",
                        path_params={"id": ctx.ids["bill_id"]}).data or {})
    r = ctx.api.get("/salons/{salon_id}/reports/payments/rows",
                    path_params={"salon_id": ctx.salon_id},
                    params={"range": "today", "page": 1, "per_page": 100})
    rows = ((r.data or {}).get("rows") or [])
    mine = [x for x in rows if str(x.get("bill_id") or x.get("bill_number") or "")
            in (str(ctx.ids["bill_id"]), str(bill.get("bill_number")))]
    assert mine, (
        f"bill {ctx.ids['bill_id']} ({bill.get('bill_number')}) was settled for "
        f"{bill.get('net_payable')} but has no row in today's Payments report")
    amounts = [D(x.get("amount") or x.get("amount_paid") or 0) for x in mine]
    assert sum(amounts, D(0)) == D(bill.get("amount_paid")), (
        f"the Payments report shows {sum(amounts, D(0))} for bill "
        f"{ctx.ids['bill_id']}, the bill itself says {bill.get('amount_paid')}")


def dashboard_agrees_with_sales(ctx):
    """100: the owner's first screen must not disagree with the report behind it."""
    d = ctx.api.get("/salons/{salon_id}/dashboard/overview",
                    path_params={"salon_id": ctx.salon_id},
                    params={"range": "today", "refresh": "true"})
    s = ctx.api.get("/salons/{salon_id}/reports/sales/summary",
                    path_params={"salon_id": ctx.salon_id}, params={"range": "today"})
    card = D(((d.data or {}).get("kpis") or {}).get("revenue", {}).get("value"))
    report = D(((s.data or {}).get("kpis") or {}).get("total_revenue", {}).get("value"))
    assert card == report, (
        f"the Dashboard revenue card says {card} for today, the Sales report "
        f"says {report} - the owner sees two different numbers for one day")


BLOCK_2 = [
    Journey("API-E2E-076", "1,000 bill, 500 paid, 500 outstanding",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-077", "1,000 bill paid as 250 then 750",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-078", "1,000 bill paid as 300, 300, 400",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),

    # --- one run, seven ids ------------------------------------------------
    Journey("API-E2E-079", "settlement: every report, checked together",
            SETTLE, settled(), (bill_is_paid, bill_belongs_to_converted_customer),
            share="settle"),
    Journey("API-E2E-080", "settlement reaches Payments collected",
            SETTLE, one("payments.total_collected", _gross), (), share="settle", guard=False),
    Journey("API-E2E-081", "settlement reaches Customer spend",
            SETTLE, one("customers.total_spend_in_range", _gross),
            (), share="settle", guard=False),
    Journey("API-E2E-082", "settlement reaches Service revenue",
            SETTLE, one("services.total_revenue", lambda c: _kind_gross(c, "service")),
            (), share="settle", guard=False),
    Journey("API-E2E-083", "settlement reaches Staff revenue",
            SETTLE, one("staff_performance.total_service_revenue", _gross),
            (), share="settle", guard=False),
    Journey("API-E2E-084", "settlement reaches Profit",
            SETTLE, lambda ctx: {"profit.gross_revenue": _taxable(ctx),
                                 "profit.net_profit": _taxable(ctx),
                                 "profit.tax_collected": _tax(ctx)},
            (), share="settle", guard=False),
    Journey("API-E2E-085", "one payment settles one bill, counted once",
            SETTLE, bills_settled_unchanged, (), share="settle", guard=False),

    Journey("API-E2E-086", "advance then balance: Bills Settled +1",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-087", "advance then balance: nothing outstanding",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-088", "advance then balance: status becomes Paid",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),

    Journey("API-E2E-089", "settle, then refund what was collected",
            tuple(CHAIN + PAY + [("refund", {})]), settled_then_refunded,
            (bill_is_refunded,)),
    Journey("API-E2E-090", "refund part, then collect again",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-091", "refund is visible in every report it touched",
            tuple(CHAIN + PAY + [("refund", {})]), settled_then_refunded,
            (bill_is_refunded,)),
    Journey("API-E2E-092", "advance, balance, then refund the whole transaction",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-093", "advance in cash, balance by card",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-094", "advance by card, balance in cash",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-095", "three payments, one refunded",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),
    Journey("API-E2E-096", "three payments, all refunded",
            SETTLE, settled(), (bill_is_paid,), skip=PARTIAL),

    Journey("API-E2E-097", "the settlement call, sent twice",
            tuple(CHAIN + PAY + [("repeat_payment", {})]), settled(),
            (bill_is_paid, no_second_collection)),
    Journey("API-E2E-098", "settlement retried after a timeout",
            tuple(CHAIN + PAY + [("repeat_payment", {}), ("repeat_payment", {})]),
            settled(), (bill_is_paid, no_second_collection)),

    Journey("API-E2E-099", "the payment ledger matches the bill it came from",
            SETTLE, settled(), (bill_is_paid, ledger_agrees_with_the_bill)),
    Journey("API-E2E-100", "settlement, reports and Dashboard reconciled",
            SETTLE, settled(),
            (bill_is_paid, ledger_agrees_with_the_bill, dashboard_agrees_with_sales)),
]
