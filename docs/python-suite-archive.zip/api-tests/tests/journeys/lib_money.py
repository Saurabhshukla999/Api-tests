"""The billing arithmetic model, written out independently of the API.

Confirmed against the live QA API on 27 Aug 2026:

    line_total = price x qty x (1 - line_disc_pct/100)
    subtotal   = sum(line_total)
    discount   = min(subtotal, subtotal x cart_pct/100 + cart_flat)   <- clamped
    taxable    = subtotal - discount
    tax        = taxable x gst_rate            (= cgst + sgst, split evenly)
    gross      = taxable + tax
    net        = gross + round_off

Every number is computed here in Decimal and compared against what the API
returned. If the API changes its mind about any step, the test that covers that
step fails and names it - rather than one opaque "total is wrong".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP

# Money is compared to the paisa. Anything looser hides real rounding faults.
TOLERANCE = Decimal("0.01")


def D(x) -> Decimal:
    return Decimal(str(x if x is not None else 0))


def money(x: Decimal) -> Decimal:
    return D(x).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class Line:
    kind: str            # "service" | "product"
    ref_id: int
    catalogue_price: Decimal
    qty: int = 1
    price_override: Decimal | None = None
    line_disc_pct: Decimal = Decimal(0)

    @property
    def unit_price(self) -> Decimal:
        return D(self.price_override if self.price_override is not None
                 else self.catalogue_price)

    @property
    def gross(self) -> Decimal:
        return money(self.unit_price * D(self.qty))

    @property
    def total(self) -> Decimal:
        return money(self.gross * (D(1) - D(self.line_disc_pct) / D(100)))

    def as_item(self) -> dict:
        item = {"type": self.kind, "ref_id": self.ref_id, "name": f"line-{self.ref_id}"}
        if self.qty != 1:
            item["qty"] = self.qty
        if self.price_override is not None:
            item["price"] = float(self.price_override)
        if self.line_disc_pct:
            item["disc_pct"] = float(self.line_disc_pct)
        return item


@dataclass(frozen=True)
class Basket:
    label: str
    lines: tuple = field(default_factory=tuple)
    cart_pct: Decimal = Decimal(0)
    cart_flat: Decimal = Decimal(0)

    # -- what we expect the API to say -------------------------------------
    @property
    def subtotal(self) -> Decimal:
        return money(sum((l.total for l in self.lines), Decimal(0)))

    @property
    def service_total(self) -> Decimal:
        return money(sum((l.total for l in self.lines if l.kind == "service"), Decimal(0)))

    @property
    def product_total(self) -> Decimal:
        return money(sum((l.total for l in self.lines if l.kind == "product"), Decimal(0)))

    @property
    def raw_discount(self) -> Decimal:
        return money(self.subtotal * D(self.cart_pct) / D(100) + D(self.cart_flat))

    @property
    def discount(self) -> Decimal:
        """Clamped: a discount can empty a bill but never invert it."""
        return money(min(self.raw_discount, self.subtotal))

    @property
    def taxable(self) -> Decimal:
        return money(self.subtotal - self.discount)

    def tax(self, rate: Decimal) -> Decimal:
        return money(self.taxable * D(rate))

    def gross(self, rate: Decimal) -> Decimal:
        return money(self.taxable + self.tax(rate))

    def body(self) -> dict:
        payload = {"items": [l.as_item() for l in self.lines]}
        if self.cart_pct or self.cart_flat:
            payload["discount"] = {}
            if self.cart_pct:
                payload["discount"]["pct"] = float(self.cart_pct)
            if self.cart_flat:
                payload["discount"]["flat"] = float(self.cart_flat)
        return payload

    @property
    def id(self) -> str:
        return self.label


# --------------------------------------------------------------------------
# reading the API's answer
# --------------------------------------------------------------------------
def actual(data: dict) -> dict:
    d = data or {}
    tax = d.get("tax") or {}
    disc = d.get("discount") or {}
    return {
        "service_total": D(d.get("service_total")),
        "product_total": D(d.get("product_total")),
        "subtotal": D(d.get("subtotal")),
        "discount": D(disc.get("total")),
        "taxable": D(d.get("taxable")),
        "tax": D(tax.get("amount")),
        "cgst": D(tax.get("cgst")),
        "sgst": D(tax.get("sgst")),
        "gross": D(d.get("gross_payable")),
        "round_off": D(d.get("round_off")),
        "net": D(d.get("net_payable")),
    }


def close(a: Decimal, b: Decimal, tol: Decimal = TOLERANCE) -> bool:
    return abs(D(a) - D(b)) <= tol


def diff(name: str, expected, got) -> str:
    return (f"\n  {name}: expected {money(D(expected))}, API said {money(D(got))}"
            f"  (out by {money(D(got) - D(expected))})")
