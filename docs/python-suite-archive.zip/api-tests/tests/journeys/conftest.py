def pytest_sessionfinish(session, exitstatus):
    try:
        from lib.client import REQUEST_COUNT
        n = REQUEST_COUNT["n"]
        t = getattr(session.config, "_start", None)
        print(f"\n>>> HTTP REQUESTS MADE: {n}")
    except Exception as e:
        print("counter unavailable", e)
