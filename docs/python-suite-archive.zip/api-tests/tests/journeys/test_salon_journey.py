"""End-to-end business journey, through the API only.

Everything else in this suite tests endpoints one at a time: does /staff accept
a valid body, does /reports/sales answer. That proves each part works. It does
NOT prove the parts are wired to each other.

This file walks one real day in a salon and checks the data actually travels:

    create a service -> create a beautician -> create a customer
      -> book the service with that beautician for that customer
      -> the booking shows up on the calendar
      -> mark it arrived / started / completed
      -> raise a bill for it and settle it
      -> the money shows up on the dashboard
      -> the bill shows up in the Sales report
      -> the beautician shows up in Staff Performance
      -> the service shows up in the Service report
      -> the customer shows up in the Customer report

A failure here means two modules disagree, which is invisible when each is
tested alone. Steps run in order and share STATE; a step whose input is missing
reports itself as blocked rather than failing for the wrong reason.

Run:  pytest tests/journeys -p no:randomly --run-destructive
      (do NOT use -n here - the steps are ordered and share state)
"""
from __future__ import annotations

import datetime as dt
import time

import pytest

pytestmark = [pytest.mark.journey, pytest.mark.destructive]

STATE: dict = {}
STAMP = time.strftime("%H%M%S")
SUFFIX = STAMP[-4:]          # keeps phones unique across re-runs
TAG = f"APITEST-{STAMP}"
TODAY = dt.date.today().isoformat()


def need(*keys):
    """Skip with a clear reason when an earlier step did not produce its output."""
    missing = [k for k in keys if not STATE.get(k)]
    if missing:
        pytest.skip(f"blocked - earlier step did not produce: {', '.join(missing)}")
    return [STATE[k] for k in keys]


def rows_of(result, *names):
    d = result.data
    if isinstance(d, list):
        return d
    if isinstance(d, dict):
        for n in names:
            if isinstance(d.get(n), list):
                return d[n]
        return next((v for v in d.values() if isinstance(v, list)), [])
    return []


def num(x):
    return x if isinstance(x, (int, float)) else 0


def payable(payload):
    """The billing module's money field is `net_payable`, at the top level and
    again inside `totals`. There is no `total` key - reading for one is how a
    client silently ends up charging zero."""
    d = payload or {}
    return num(d.get("net_payable") or (d.get("totals") or {}).get("net_payable"))


# ---------------------------------------------------------------------------
# 1. where we start
# ---------------------------------------------------------------------------
def test_01_baseline(api, salon_id):
    """Record the numbers before anything happens, so we can prove they moved."""
    ov = api.get("/salons/{salon_id}/dashboard/overview",
                 path_params={"salon_id": salon_id}, params={"range": "today"})
    assert ov.status == 200, ov.explain()
    kpis = (ov.data or {}).get("kpis") or {}
    STATE["revenue_before"] = num((kpis.get("revenue") or {}).get("value"))
    STATE["appointments_before"] = num((kpis.get("appointments") or {}).get("value"))

    sales = api.get("/salons/{salon_id}/reports/sales/rows",
                    path_params={"salon_id": salon_id},
                    params={"range": "today", "page": 1, "per_page": 1})
    STATE["sales_rows_before"] = ((sales.json or {}).get("meta") or {}).get("total", 0) \
        if sales.status == 200 else None

    print(f"\n  baseline: revenue={STATE['revenue_before']} "
          f"appointments={STATE['appointments_before']} sales_rows={STATE['sales_rows_before']}")


# ---------------------------------------------------------------------------
# 2. set the salon up
# ---------------------------------------------------------------------------
def test_02_create_service(api, salon_id):
    r = api.post("/salon_services", json={
        "salon_id": int(salon_id),
        "category": "APITEST Category",
        "custom_name": f"{TAG} Haircut",
        "price": 500,
        "duration_in_minutes": 30,
        "gender": "unisex",
        "active": True,
    })
    assert r.status in (200, 201), "could not create a service" + r.explain()
    STATE["service_id"] = (r.data or {}).get("id")
    assert STATE["service_id"], "service created but no id returned" + r.explain()


def test_03_created_service_is_listed(api, salon_id):
    (svc,) = need("service_id")
    r = api.get("/salon_services", params={"salon_id": salon_id, "per_page": 100})
    assert r.status == 200, r.explain()
    ids = [x.get("id") for x in rows_of(r, "salon_services", "items") if isinstance(x, dict)]
    assert svc in ids, "the service was created but does not appear in the services list"


def test_04_create_beautician(api, salon_id):
    # NOTE: swagger's example for this endpoint shows only {name, phone, email}
    # and is rejected - job_title, shift_start and shift_end are required too.
    r = api.post("/salons/{salon_id}/staff", path_params={"salon_id": salon_id},
                 json={"name": f"{TAG} Beautician", "phone": f"91{SUFFIX}0001",
                       "email": f"apitest{STAMP}@example.com",
                       "job_title": "Beautician", "role": "Beautician",
                       "shift_start": "10:00", "shift_end": "19:00"})
    assert r.status in (200, 201), "could not create a beautician" + r.explain()
    STATE["staff_id"] = (r.data or {}).get("id")
    assert STATE["staff_id"], "beautician created but no id returned" + r.explain()


def test_05_create_customer(api, salon_id):
    r = api.post("/salons/{salon_id}/salon_customer_profiles",
                 path_params={"salon_id": salon_id},
                 # swagger's example omits `gender`, which the API requires.
                 json={"salon_customer_profile": {"mobile": f"92{SUFFIX}0002",
                                                  "full_name": f"{TAG} Customer",
                                                  "gender": "female"}})
    assert r.status in (200, 201, 422), r.explain()
    if r.status == 422:
        # already exists from a previous run - find them instead
        find = api.get("/salons/{salon_id}/salon_customer_profiles",
                       path_params={"salon_id": salon_id}, params={"q": f"92{SUFFIX}0002"})
        rows = rows_of(find, "salon_customer_profiles", "items")
        STATE["customer_id"] = rows[0].get("id") if rows else None
    else:
        STATE["customer_id"] = (r.data or {}).get("id")
    assert STATE["customer_id"], "no customer id to book with" + r.explain()


# ---------------------------------------------------------------------------
# 3. the booking
# ---------------------------------------------------------------------------
def test_06_book_the_service_with_that_beautician(api, salon_id):
    svc, staff = need("service_id", "staff_id")
    r = api.post("/appointments", json={"appointment": {
        "salon_id": int(salon_id),
        "date": TODAY,
        "start_time": "11:00",
        "end_time": "11:30",
        "comment": f"{TAG} journey booking",
        "appointment_services_attributes": [
            {"salon_service_id": svc, "staff_id": staff}
        ],
    }})
    assert r.status in (200, 201), "could not book the service" + r.explain()
    STATE["appointment_id"] = (r.data or {}).get("id")
    assert STATE["appointment_id"], "booking made but no id returned" + r.explain()


def test_07_booking_shows_on_the_day_grid(api, salon_id):
    (appt,) = need("appointment_id")
    r = api.get("/salons/{id}/appointments", path_params={"id": salon_id},
                params={"date": TODAY, "per_page": 100})
    assert r.status == 200, r.explain()
    ids = [x.get("id") for x in rows_of(r, "appointments", "items") if isinstance(x, dict)]
    assert appt in ids, (
        "the booking was created but does not appear on today's calendar - "
        "the calendar and the booking endpoint disagree")


def test_08_booking_is_counted_in_the_day_summary(api, salon_id):
    need("appointment_id")
    r = api.get("/salons/{salon_id}/appointments/summary",
                path_params={"salon_id": salon_id}, params={"date": TODAY})
    if r.status != 200:
        pytest.skip(f"summary returned {r.status}")
    summary = (r.data or {}).get("summary") or {}
    total = summary.get("total_bookings")
    assert num(total) >= 1, (
        f"a booking exists for today but the day summary counts none: {summary}")


def test_09_the_assigned_beautician_is_on_the_booking(api, salon_id):
    appt, staff = need("appointment_id", "staff_id")
    r = api.get("/salons/{id}/appointments", path_params={"id": salon_id},
                params={"date": TODAY, "staff_id": staff, "per_page": 100})
    if r.status != 200:
        pytest.skip(f"filtered list returned {r.status}")
    ids = [x.get("id") for x in rows_of(r, "appointments", "items") if isinstance(x, dict)]
    assert appt in ids, (
        f"the booking was assigned to beautician {staff}, but filtering the day "
        f"by that beautician does not return it")


@pytest.mark.parametrize("status", ["arrived", "started", "completed"])
def test_10_move_the_booking_through_its_statuses(api, status):
    (appt,) = need("appointment_id")
    r = api.patch("/appointments/{id}/status", path_params={"id": appt},
                  json={"status": status})
    assert r.status in (200, 201), f"could not set status to {status}" + r.explain()


# ---------------------------------------------------------------------------
# 4. the money
# ---------------------------------------------------------------------------
def test_10b_new_service_is_sellable_in_billing(api):
    """The Salon Setup module created it; the Billing module has to be able to
    find and price it. Two separate modules, one shared catalogue."""
    (svc,) = need("service_id")
    r = api.get("/api/v1/billing/catalogue/search",
                params={"q": TAG, "types": "service", "limit": 5})
    assert r.status == 200, r.explain()
    hits = [x for x in rows_of(r, "results", "items") if isinstance(x, dict)]
    match = next((h for h in hits if h.get("ref_id") == svc), None)
    assert match, (
        f"the service was created in Salon Setup but Billing's catalogue cannot "
        f"find it - the two modules are not sharing the same list")
    assert num(match.get("price")) > 0, "billing found the service but with no price"
    STATE["service_price"] = num(match.get("price"))


def test_11_preview_the_bill(api):
    svc, cust = need("service_id", "customer_id")
    r = api.post("/api/v1/billing/bills/calculate", json={
        "customer_id": cust,
        "items": [{"type": "service", "ref_id": svc, "name": f"{TAG} Haircut"}],
    })
    assert r.status == 200, "could not preview the bill" + r.explain()
    STATE["preview_total"] = payable(r.data)
    assert STATE["preview_total"] > 0, (
        "the bill preview priced this service at zero" + r.explain())


def test_12_raise_the_bill(api):
    svc, cust = need("service_id", "customer_id")
    r = api.post("/api/v1/billing/bills", json={
        "customer_id": cust,
        "status": "draft",
        "items": [{"type": "service", "ref_id": svc, "name": f"{TAG} Haircut"}],
    })
    assert r.status in (200, 201), "could not raise the bill" + r.explain()
    STATE["bill_id"] = (r.data or {}).get("id")
    assert STATE["bill_id"], "bill created but no id returned" + r.explain()


def test_13_preview_total_matches_the_saved_bill(api):
    bill, preview = need("bill_id", "preview_total")
    r = api.get("/api/v1/billing/bills/{id}", path_params={"id": bill})
    assert r.status == 200, r.explain()
    saved = payable(r.data)
    assert saved == preview, (
        f"the preview said {preview} but the saved bill says {saved} - "
        f"the customer was quoted one price and charged another")


def test_14_settle_the_bill(api):
    """Finalize requires a customer, at least one item, and a payment that
    matches the net payable exactly - all three are enforced, correctly."""
    (bill,) = need("bill_id")
    detail = api.get("/api/v1/billing/bills/{id}", path_params={"id": bill})
    assert detail.status == 200, detail.explain()
    d = detail.data or {}
    assert d.get("customer_id"), (
        "the draft bill has no customer attached, so it can never be settled - "
        "the bill was accepted without one" + detail.explain())
    net = payable(d)
    assert net > 0, f"the draft bill has no net payable to settle: {d}"
    STATE["net_payable"] = net

    # Billing::PaymentIntent reads params[:payment] - singular - and accepts
    # either {mode, amount_paid} or a {modes:[...]} split. `payments` is ignored,
    # which reads back as "amount does not match".
    r = api.post("/api/v1/billing/bills/{id}/finalize", path_params={"id": bill},
                 json={"payment": {"mode": "cash", "amount_paid": net}})
    assert r.status in (200, 201), "could not settle the bill" + r.explain()


# ---------------------------------------------------------------------------
# 5. does any of it reach the reports?
# ---------------------------------------------------------------------------
# Deliberately not here any more.
#
# This file used to end with six checks of the form "revenue went up", "the
# bill appears in the Sales report". test_journey_arithmetic.py now asserts the
# EXACT delta on all ten reports - revenue moved by 945.00, not merely upward -
# and adds sixteen "must not move" invariants besides.
#
# "It went up" is a weaker statement than "it went up by exactly this much", so
# running both meant paying for the weak one. The strong version lives next
# door; this file's job is the FLOW, that file's job is the NUMBERS.

# ---------------------------------------------------------------------------
# 6. put the salon back
# ---------------------------------------------------------------------------
def test_99_cleanup(api, salon_id):
    """Best effort. Reports what it could not remove rather than failing."""
    left = []
    if STATE.get("appointment_id"):
        r = api.put("/appointments/{id}/cancel", path_params={"id": STATE["appointment_id"]})
        if r.status not in (200, 204):
            left.append(f"appointment {STATE['appointment_id']}")
    if STATE.get("service_id"):
        r = api.delete("/salon_services/{id}", path_params={"id": STATE["service_id"]})
        if r.status not in (200, 204):
            left.append(f"service {STATE['service_id']}")
    if STATE.get("staff_id"):
        r = api.delete("/salons/{salon_id}/staff/{id}",
                       path_params={"salon_id": salon_id, "id": STATE["staff_id"]})
        if r.status not in (200, 204):
            left.append(f"staff {STATE['staff_id']}")
    if left:
        print(f"\n  NOT removed (settled bills cannot be deleted by design): {', '.join(left)}")
    print(f"\n  journey records tagged: {TAG}")
