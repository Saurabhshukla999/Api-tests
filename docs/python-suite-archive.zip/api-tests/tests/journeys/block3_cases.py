"""Block 3 - API-E2E-101 .. 125. Refunds and reversal.

This is where the known Sales-vs-Payments gap lives, so the assertions here are
deliberately two-sided: a refund must take the money back out of every report it
put money into, AND it must appear as a refund rather than simply vanishing. A
reversal that quietly deleted the sale from both sides would satisfy a naive
"revenue went back to zero" check.

101-108 are the lead's list asking eight questions of one reversal. They share a
single run: one refund, eight test ids. 101 carries the full expectation and the
guard; 102-108 each state their own surface.

Partial refunds (114, 115, 123) use PATCH /bills/:id/refund with an explicit
`amount`. That is a different feature from partial PAYMENTS - RefundProcessor
supports repeated part-refunds against what was collected, and the frontend's
confirm dialog simply omits the field. Only partial payments are parked.
"""
from __future__ import annotations

from tests.journeys.lib_journey import Journey
from tests.journeys.lib_money import D, money
from tests.journeys.block1_cases import (
    CHAIN, PAY, settled, settled_then_refunded, _gross, _rate, _last,
    _refunded, _taxable, _tax, _kind_gross, _discount,
    bill_is_paid, bill_is_refunded)
from tests.journeys.block2_cases import one, PARTIAL

REFUND = tuple(CHAIN + PAY + [("refund", {})])


# --------------------------------------------------------------------------
# checks
# --------------------------------------------------------------------------
def refund_is_recorded_not_erased(ctx):
    """A reversal must leave a trace. Silent deletion also nets to zero."""
    bill = (ctx.api.get("/api/v1/billing/bills/{id}",
                        path_params={"id": ctx.ids["bill_id"]}).data or {})
    assert D(bill.get("refund_amount")) > D(0), (
        f"bill {ctx.ids['bill_id']} nets to zero revenue but carries no "
        f"refund_amount - the sale was erased rather than reversed")
    assert bill.get("refunded_at"), (
        f"bill {ctx.ids['bill_id']} was refunded but has no refunded_at "
        f"timestamp - there is no audit trail for the money going back")


def part_refund_leaves_the_bill_counted(ctx):
    """A part refund is a price adjustment, not an unwind - the sale stands."""
    bill = (ctx.api.get("/api/v1/billing/bills/{id}",
                        path_params={"id": ctx.ids["bill_id"]}).data or {})
    assert bill.get("status") == "partially_refunded", (
        f"a part refund on bill {ctx.ids['bill_id']} left status "
        f"{bill.get('status')!r}; RefundProcessor sets 'partially_refunded'")


def dashboard_follows_the_reversal(ctx):
    """107: the owner's first screen must reverse with everything else."""
    d = ctx.api.get("/salons/{salon_id}/dashboard/overview",
                    path_params={"salon_id": ctx.salon_id},
                    params={"range": "today", "refresh": "true"})
    s = ctx.api.get("/salons/{salon_id}/reports/sales/summary",
                    path_params={"salon_id": ctx.salon_id}, params={"range": "today"})
    card = D(((d.data or {}).get("kpis") or {}).get("revenue", {}).get("value"))
    report = D(((s.data or {}).get("kpis") or {}).get("total_revenue", {}).get("value"))
    assert card == report, (
        f"after a full refund the Dashboard revenue card says {card} and the "
        f"Sales report says {report} - the reversal reached one and not the other")


def books_did_not_move(ctx):
    """123: the invalid refund was refused; nothing may have changed."""
    bill = (ctx.api.get("/api/v1/billing/bills/{id}",
                        path_params={"id": ctx.ids["bill_id"]}).data or {})
    assert bill.get("status") == "paid", (
        f"an invalid refund was refused, but bill {ctx.ids['bill_id']} is now "
        f"{bill.get('status')!r} instead of 'paid'")
    assert D(bill.get("refund_amount")) == D(0), (
        f"an invalid refund was refused, but bill {ctx.ids['bill_id']} now "
        f"carries refund_amount {bill.get('refund_amount')}")


def part_refund_expect(fraction, kind=None):
    """Refund a named slice of the bill and expect exactly that slice back."""
    def expect(ctx):
        rate = _rate(ctx)
        b = ctx.baskets[-1]
        gross = b.gross(rate)
        back = money(_kind_gross(ctx, kind)) if kind else money(gross * D(fraction))
        return {
            "sales.total_revenue":            money(gross - back),
            "payments.total_collected":       money(gross - back),
            "payments.failed_refunded_amount": back,
            "customers.total_spend_in_range": money(gross - back),
        }
    return expect


BLOCK_3 = [
    # --- one reversal, eight ids ------------------------------------------
    Journey("API-E2E-101", "full refund: every report reversed together",
            REFUND, settled_then_refunded,
            (bill_is_refunded, refund_is_recorded_not_erased), share="refund"),
    Journey("API-E2E-102", "full refund reverses Payments",
            REFUND, lambda ctx: {"payments.total_collected": D(0),
                                 "payments.failed_refunded_amount": _refunded(ctx)},
            (), share="refund", guard=False),
    Journey("API-E2E-103", "full refund reverses Customer spend",
            REFUND, one("customers.total_spend_in_range", lambda c: D(0)),
            (), share="refund", guard=False),
    Journey("API-E2E-104", "full refund reverses Services",
            REFUND, one("services.total_revenue", lambda c: D(0)),
            (), share="refund", guard=False),
    Journey("API-E2E-105", "full refund reverses Staff revenue",
            REFUND, one("staff_performance.total_service_revenue", lambda c: D(0)),
            (), share="refund", guard=False),
    Journey("API-E2E-106", "full refund reverses Profit",
            REFUND, lambda ctx: {"profit.gross_revenue": D(0),
                                 "profit.net_profit": D(0),
                                 "profit.tax_collected": D(0)},
            (), share="refund", guard=False),
    Journey("API-E2E-107", "full refund reverses the Dashboard too",
            REFUND, one("sales.total_revenue", lambda c: D(0)),
            (dashboard_follows_the_reversal,), share="refund", guard=False),
    Journey("API-E2E-108", "full refund leaves a refund on the record",
            REFUND, one("sales.total_revenue", lambda c: D(0)),
            (refund_is_recorded_not_erased,), share="refund", guard=False),

    Journey("API-E2E-109", "refund only the portion collected",
            REFUND, settled_then_refunded, (bill_is_refunded,), skip=PARTIAL),
    Journey("API-E2E-110", "advance, balance, then refund it all",
            REFUND, settled_then_refunded, (bill_is_refunded,), skip=PARTIAL),
    Journey("API-E2E-111", "two payments, first refunded",
            REFUND, settled_then_refunded, (bill_is_refunded,), skip=PARTIAL),
    Journey("API-E2E-112", "two payments, second refunded",
            REFUND, settled_then_refunded, (bill_is_refunded,), skip=PARTIAL),
    Journey("API-E2E-113", "two payments, both refunded",
            REFUND, settled_then_refunded, (bill_is_refunded,), skip=PARTIAL),

    Journey("API-E2E-114", "service and product billed, service refunded",
            tuple(CHAIN + [("bill", {"services": 1, "products": 1}), ("finalize", {}),
                           ("refund", {"amount": 1180.0})]),
            part_refund_expect(None, kind="service"),
            (part_refund_leaves_the_bill_counted,),
            tolerate=("sales.bills_count", "sales.service_revenue",
                      "sales.product_revenue", "services.total_revenue",
                      "services.services_sold", "customers.new_customers",
                      "payments.payments_count", "profit.gross_revenue",
                      "profit.net_profit", "profit.tax_collected",
                      "profit.total_discount", "sales.total_discount",
                      "staff_performance.total_service_revenue")),
    Journey("API-E2E-115", "service and product billed, product refunded",
            tuple(CHAIN + [("bill", {"services": 1, "products": 1}), ("finalize", {}),
                           ("refund", {"amount": 236.0})]),
            part_refund_expect(None, kind="product"),
            (part_refund_leaves_the_bill_counted,),
            tolerate=("sales.bills_count", "sales.service_revenue",
                      "sales.product_revenue", "services.total_revenue",
                      "services.services_sold", "customers.new_customers",
                      "payments.payments_count", "profit.gross_revenue",
                      "profit.net_profit", "profit.tax_collected",
                      "profit.total_discount", "sales.total_discount",
                      "staff_performance.total_service_revenue")),
    Journey("API-E2E-116", "service and product billed, whole bill refunded",
            tuple(CHAIN + [("bill", {"services": 1, "products": 1}), ("finalize", {}),
                           ("refund", {})]),
            lambda ctx: {"sales.total_revenue": D(0),
                         "payments.total_collected": D(0),
                         "payments.failed_refunded_amount": _last(ctx),
                         "customers.total_spend_in_range": D(0)},
            (bill_is_refunded, refund_is_recorded_not_erased),
            tolerate=("sales.bills_count", "sales.service_revenue",
                      "sales.product_revenue", "services.total_revenue",
                      "services.services_sold", "customers.new_customers",
                      "payments.payments_count", "profit.gross_revenue",
                      "profit.net_profit", "profit.tax_collected",
                      "staff_performance.total_service_revenue")),

    # FINDING C (28 Aug 2026): a fully refunded bill reverses its revenue to
    # zero but LEAVES its discount on the books. A Rs 1,000 service at 10% off,
    # paid then fully refunded, moves Sales revenue by 0 and Sales discount by
    # +100 - so Profit reports Rs 0 of revenue alongside Rs 100 of discount
    # given. Asserted as observed so the number is locked and any change is
    # visible; raised with the backend team rather than quietly tolerated.
    Journey("API-E2E-117", "a discounted bill, refunded",
            tuple(CHAIN + [("bill", {"services": 1, "disc_pct": 10}),
                           ("finalize", {}), ("refund", {})]),
            lambda ctx: dict(settled_then_refunded(ctx),
                             **{"sales.total_discount":  _discount(ctx),
                                "profit.total_discount": _discount(ctx)}),
            (bill_is_refunded, refund_is_recorded_not_erased)),
    Journey("API-E2E-118", "a GST bill, refunded",
            tuple(CHAIN + [("bill", {"services": 1, "gst": True}),
                           ("finalize", {}), ("refund", {})]),
            settled_then_refunded, (bill_is_refunded, refund_is_recorded_not_erased)),
    Journey("API-E2E-119", "a GST-disabled bill, refunded",
            tuple(CHAIN + [("bill", {"services": 1, "gst": False}),
                           ("finalize", {}), ("refund", {})]),
            settled_then_refunded, (bill_is_refunded, refund_is_recorded_not_erased)),

    Journey("API-E2E-120", "refunded, then the same customer buys again",
            tuple(CHAIN + PAY + [("refund", {}), ("appointment", {}),
                                 ("status", {"to": "completed"}),
                                 ("second_bill", {"services": 1}), ("finalize", {})]),
            lambda ctx: {
                "sales.bills_count":                       D(1),
                "sales.total_revenue":                     _last(ctx),
                "sales.service_revenue":                   _last(ctx),
                "sales.total_discount":                    D(0),
                "payments.payments_count":                 D(1),
                "payments.total_collected":                _last(ctx),
                "payments.failed_refunded_amount":         _refunded(ctx, 0),
                "customers.new_customers":                 D(1),
                "customers.total_spend_in_range":          _last(ctx),
                "profit.gross_revenue":                    ctx.baskets[-1].taxable,
                "profit.net_profit":                       ctx.baskets[-1].taxable,
                "profit.tax_collected":                    ctx.baskets[-1].tax(_rate(ctx)),
                "profit.total_discount":                   D(0),
                "services.total_revenue":                  _last(ctx),
                "services.services_sold":                  D(1),
                "staff_performance.total_service_revenue": _last(ctx)},
            (bill_is_paid,)),

    Journey("API-E2E-121", "a second bill and a second refund",
            tuple(CHAIN + PAY + [("refund", {}), ("appointment", {}),
                                 ("status", {"to": "completed"}),
                                 ("second_bill", {"services": 1}),
                                 ("finalize", {}), ("refund", {})]),
            lambda ctx: {"sales.total_revenue": D(0),
                         "payments.total_collected": D(0),
                         "customers.total_spend_in_range": D(0),
                         "payments.failed_refunded_amount":
                             money(_refunded(ctx, 0) + _refunded(ctx, 1))},
            (bill_is_refunded,),
            tolerate=("sales.bills_count", "sales.service_revenue",
                      "sales.total_discount", "services.total_revenue",
                      "services.services_sold", "customers.new_customers",
                      "payments.payments_count", "profit.gross_revenue",
                      "profit.net_profit", "profit.tax_collected",
                      "profit.total_discount",
                      "staff_performance.total_service_revenue")),

    Journey("API-E2E-122", "the refund call, sent twice",
            tuple(CHAIN + PAY + [("refund", {}), ("bad_refund", {"reason": "retry"})]),
            settled_then_refunded, (bill_is_refunded, refund_is_recorded_not_erased)),

    Journey("API-E2E-123", "a refund larger than the bill is refused",
            tuple(CHAIN + PAY + [("bad_refund", {"amount": 999999.0,
                                                 "reason": "over-refund"})]),
            settled(), (bill_is_paid, books_did_not_move)),

    Journey("API-E2E-124", "before and after, across every report the refund touches",
            REFUND, settled_then_refunded,
            (bill_is_refunded, refund_is_recorded_not_erased,
             dashboard_follows_the_reversal)),

    Journey("API-E2E-125", "settle, refund, sell again, reconcile",
            tuple(CHAIN + PAY + [("refund", {}), ("appointment", {}),
                                 ("status", {"to": "completed"}),
                                 ("second_bill", {"services": 1}), ("finalize", {})]),
            lambda ctx: {
                "sales.bills_count":                       D(1),
                "sales.total_revenue":                     _last(ctx),
                "sales.service_revenue":                   _last(ctx),
                "sales.total_discount":                    D(0),
                "payments.payments_count":                 D(1),
                "payments.total_collected":                _last(ctx),
                "payments.failed_refunded_amount":         _refunded(ctx, 0),
                "customers.new_customers":                 D(1),
                "customers.total_spend_in_range":          _last(ctx),
                "profit.gross_revenue":                    ctx.baskets[-1].taxable,
                "profit.net_profit":                       ctx.baskets[-1].taxable,
                "profit.tax_collected":                    ctx.baskets[-1].tax(_rate(ctx)),
                "profit.total_discount":                   D(0),
                "services.total_revenue":                  _last(ctx),
                "services.services_sold":                  D(1),
                "staff_performance.total_service_revenue": _last(ctx)},
            (bill_is_paid, dashboard_follows_the_reversal)),
]
