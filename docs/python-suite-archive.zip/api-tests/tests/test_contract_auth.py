"""Token handling. Eight requests, kept because no journey can catch this.

A journey always sends a valid owner token - that is what makes it a journey.
So a journey can never notice that a *bad* token is accepted. These eight
checks cover that blind spot for the cost of eight HTTP requests.

The full 173-endpoint unauthenticated sweep that used to live here was removed
on 2026-08-28: it passed on every run and cost 173 requests a night. It is
preserved in .backup-2026-08-28/ and can be restored on demand if the auth
middleware is ever touched.
"""
import pytest

from lib.auth import GARBAGE_TOKENS, FORGED_JWT
from lib.client import ApiClient

pytestmark = [pytest.mark.contract, pytest.mark.auth]

# One representative read endpoint. If the middleware refuses a bad token here
# it refuses it everywhere - the check is on the middleware, not the route.
PROBE = "/salons/{salon_id}/dashboard/meta"


def test_no_token_at_all_is_refused(api_anon, salon_id):
    """No Authorization header -> 401, and the 401 must not leak a stack trace."""
    r = api_anon.get(PROBE, path_params={"salon_id": salon_id})

    assert r.status != 200, "served dashboard data with NO token" + r.explain()
    assert r.status == 401, f"expected 401, got {r.status}" + r.explain()

    body = (r.response.text or "").lower()
    for leak in ("activerecord::", "nomethoderror", "/app/controllers/", "gems/"):
        assert leak not in body, f"the 401 body leaks internals ({leak})" + r.explain()


@pytest.mark.parametrize("label,token", sorted(GARBAGE_TOKENS.items()))
def test_rejects_bad_token(config, salon_id, label, token):
    """A malformed or wrongly-signed JWT must be refused, not merely parsed."""
    client = ApiClient(config["base_url"], token or None, config["timeout"], label)
    if not token:
        client.session.headers["Authorization"] = "Bearer"
    r = client.get(PROBE, path_params={"salon_id": salon_id})
    assert r.status == 401, f"token '{label}' was not rejected" + r.explain()


def test_forged_admin_claim_is_not_trusted(config):
    """The forged JWT claims role=admin. If the signature check is sound this is
    indistinguishable from any other bad token."""
    client = ApiClient(config["base_url"], FORGED_JWT, config["timeout"], "forged")
    r = client.get("/admins/salons")
    assert r.status in (401, 403, 404), (
        "a self-signed token with role=admin reached an admin route" + r.explain())
