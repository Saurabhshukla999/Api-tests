"""Loads swagger/v1/*.json and exposes every B2B endpoint as an Endpoint object.

The whole suite is driven from here: parametrized contract tests iterate
`load_endpoints()`, so an endpoint added to the swagger spec is tested the next
time the suite runs, with no test code change.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SWAGGER_DIR = os.path.join(ROOT, "swagger", "v1")

METHODS = ("get", "post", "put", "patch", "delete")

# The seven modules of the B2B salon-management dashboard.
MODULE_FILES = {
    "dashboard.json": "Business Dashboard",
    "salon_setup.json": "Salon Setup",
    "appointment_calendar.json": "Appointment Calendar",
    "billing.json": "Billing & Invoicing",
    "attendance.json": "Attendance",
    "reports.json": "Reports",
    "salon_settings.json": "Salon Settings",
    # Reachable from the dashboard, documented in their own files.
    "customer_information.json": "Salon Setup",
    "customer_memberships.json": "Billing & Invoicing",
    "membership_plans.json": "Billing & Invoicing",
    "appointments.json": "Appointment Calendar",
}

SAFE_METHODS = {"GET"}


def _resolve(node: Any, doc: dict, depth: int = 0) -> Any:
    """Inline local $refs so jsonschema never needs a resolver."""
    if depth > 25:
        return {}
    if isinstance(node, dict):
        ref = node.get("$ref")
        if isinstance(ref, str) and ref.startswith("#/"):
            target: Any = doc
            for part in ref[2:].split("/"):
                part = part.replace("~1", "/").replace("~0", "~")
                if not isinstance(target, dict) or part not in target:
                    return {}
                target = target[part]
            merged = _resolve(target, doc, depth + 1)
            extra = {k: v for k, v in node.items() if k != "$ref"}
            if extra and isinstance(merged, dict):
                merged = {**merged, **_resolve(extra, doc, depth + 1)}
            return merged
        return {k: _resolve(v, doc, depth + 1) for k, v in node.items()}
    if isinstance(node, list):
        return [_resolve(v, doc, depth + 1) for v in node]
    return node


@dataclass
class Endpoint:
    module: str
    tag: str
    method: str
    path: str
    summary: str
    operation: dict = field(repr=False, default_factory=dict)
    source_file: str = ""

    # -- shape helpers ------------------------------------------------------
    @property
    def salon_scoped(self) -> bool:
        """True when the salon is named in the PATH - either as {salon_id} or,
        on the older routes, as the plain {id} of /salons/{id}/..."""
        return "{salon_id}" in self.path or self.path.startswith("/salons/{id}")

    @property
    def salon_param(self) -> str | None:
        """Which path param carries the salon id."""
        if "{salon_id}" in self.path:
            return "salon_id"
        if self.path.startswith("/salons/{id}"):
            return "id"
        return None

    @property
    def salon_in_query(self) -> bool:
        """Endpoints that take salon_id as a QUERY param instead of a path
        segment - /salon_services and friends. These sit outside the
        SalonScoped concern, so their authorization is hand-rolled per action
        and has to be tested separately."""
        return any(p.get("name") == "salon_id" for p in self.query_params)

    @property
    def object_id_params(self) -> list[str]:
        """Path params identifying a record rather than the salon."""
        salon = self.salon_param
        return [n for n in self.path_params if n != salon]

    @property
    def unscoped_object(self) -> bool:
        """Takes a record id but no salon anywhere - /appointments/{id},
        /api/v1/billing/bills/{id}, /customer_memberships/{id}. Authorization
        rests entirely on the record's own ownership check: classic IDOR shape."""
        return bool(self.object_id_params) and not self.salon_scoped

    @property
    def is_safe(self) -> bool:
        """Safe = calling it with a valid token cannot change state."""
        return self.method in SAFE_METHODS

    @property
    def path_params(self) -> list[str]:
        return [p["name"] for p in self.operation.get("parameters", [])
                if p.get("in") == "path"]

    @property
    def query_params(self) -> list[dict]:
        return [p for p in self.operation.get("parameters", []) if p.get("in") == "query"]

    @property
    def required_query(self) -> list[dict]:
        return [p for p in self.query_params if p.get("required")]

    @property
    def documented_codes(self) -> list[str]:
        return sorted(str(c) for c in self.operation.get("responses", {}))

    @property
    def requires_auth(self) -> bool:
        sec = self.operation.get("security")
        return True if sec is None else bool(sec)

    def response_schema(self, code: str = "200") -> dict | None:
        resp = self.operation.get("responses", {}).get(code)
        if not isinstance(resp, dict):
            return None
        content = resp.get("content") or {}
        for media, body in content.items():
            if "json" in media and isinstance(body, dict):
                return body.get("schema")
        return None

    def example_body(self) -> dict | None:
        rb = self.operation.get("requestBody") or {}
        for media, body in (rb.get("content") or {}).items():
            if "json" not in media or not isinstance(body, dict):
                continue
            if "example" in body:
                return body["example"]
            examples = body.get("examples") or {}
            for ex in examples.values():
                if isinstance(ex, dict) and "value" in ex:
                    return ex["value"]
            schema = body.get("schema") or {}
            if schema:
                return _synth(schema)
        return None

    @property
    def id(self) -> str:
        return f"{self.method} {self.path}"

    def __str__(self) -> str:
        return self.id


def _synth(schema: dict, depth: int = 0) -> Any:
    """Minimal instance satisfying a schema - used when swagger has no example."""
    if depth > 6 or not isinstance(schema, dict):
        return None
    if "example" in schema:
        return schema["example"]
    if "enum" in schema and schema["enum"]:
        return schema["enum"][0]
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        props = schema.get("properties") or {}
        required = schema.get("required") or list(props)[:3]
        return {k: _synth(props[k], depth + 1) for k in required if k in props}
    if t == "array":
        return [_synth(schema.get("items") or {}, depth + 1)]
    return {"string": "test", "integer": 1, "number": 1.0,
            "boolean": True, "null": None}.get(t, "test")


@lru_cache(maxsize=1)
def load_endpoints() -> tuple[Endpoint, ...]:
    out: list[Endpoint] = []
    for fname, module in MODULE_FILES.items():
        full = os.path.join(SWAGGER_DIR, fname)
        if not os.path.exists(full):
            continue
        with open(full, encoding="utf-8") as fh:
            doc = json.load(fh)
        for url, item in (doc.get("paths") or {}).items():
            if not isinstance(item, dict):
                continue
            shared = item.get("parameters") or []
            for method, op in item.items():
                if method.lower() not in METHODS or not isinstance(op, dict):
                    continue
                merged = dict(op)
                merged["parameters"] = _resolve(list(shared) + list(op.get("parameters") or []), doc)
                merged["responses"] = _resolve(op.get("responses") or {}, doc)
                if op.get("requestBody"):
                    merged["requestBody"] = _resolve(op["requestBody"], doc)
                out.append(Endpoint(
                    module=module,
                    tag=(op.get("tags") or ["-"])[0],
                    method=method.upper(),
                    path=url,
                    summary=(op.get("summary") or "").replace("\n", " "),
                    operation=merged,
                    source_file=fname,
                ))
    return tuple(sorted(out, key=lambda e: (e.module, e.path, e.method)))


def endpoints(module: str | None = None, safe_only: bool = False,
              salon_scoped: bool | None = None) -> list[Endpoint]:
    eps = list(load_endpoints())
    if module:
        eps = [e for e in eps if e.module == module]
    if safe_only:
        eps = [e for e in eps if e.is_safe]
    if salon_scoped is not None:
        eps = [e for e in eps if e.salon_scoped is salon_scoped]
    return eps


def ids(eps) -> list[str]:
    return [e.id for e in eps]


if __name__ == "__main__":
    import collections
    eps = load_endpoints()
    by = collections.Counter(e.module for e in eps)
    print(f"{len(eps)} endpoints across {len(by)} modules")
    for m, c in sorted(by.items()):
        safe = sum(1 for e in eps if e.module == m and e.is_safe)
        print(f"  {m:<24} {c:>3}  ({safe} GET / {c - safe} write)")


def documented_body(endpoint_id: str) -> dict | None:
    """The request body the API's own spec documents for this endpoint.

    Use this when writing a test that sends a body. Every payload mistake in
    this suite came from inventing a shape instead of reading one:

        {"employee_id": 1, ...}              invented — rejected
        {"attendance": {"employee_id": 1}}   documented — accepted

    So start from the spec:

        body = documented_body("PUT /salons/{salon_id}/attendance/entries")
        body["attendance"]["status"] = "present"
    """
    for e in load_endpoints():
        if e.id == endpoint_id:
            return e.example_body()
    raise KeyError(f"{endpoint_id} is not in swagger/v1 — check the id, or the "
                   f"endpoint is undocumented (which is itself a finding)")
