"""Filling path and query params for generated tests.

Contract tests fire at every endpoint, most of which need ids the suite has no
reason to know. Two different fills are used:

  dummy_path_params  - for tests where the request must be rejected BEFORE any
                       record lookup (missing token, wrong tenant). A plausible
                       but meaningless id is correct here: if the API reaches
                       the database at all, that is the finding.
  required_query     - smallest set of query params that makes a request valid,
                       so a 4xx means "the endpoint rejected us" and not
                       "we forgot a parameter".
"""
from __future__ import annotations

# Sensible values for the non-id path params that appear in the B2B spec.
NAMED_DEFAULTS = {
    "report_key": "sales",
    "token": "not-a-real-invoice-token",
    "uuid": "00000000-0000-0000-0000-000000000000",
}

# An id high enough that it is very unlikely to exist in any QA database.
UNLIKELY_ID = 99999999


def dummy_path_params(endpoint, salon_id=None) -> dict:
    out = {}
    salon_param = getattr(endpoint, "salon_param", "salon_id")
    for name in endpoint.path_params:
        if name == salon_param and salon_id is not None:
            out[name] = salon_id
        elif name in NAMED_DEFAULTS:
            out[name] = NAMED_DEFAULTS[name]
        else:
            out[name] = UNLIKELY_ID
    return out


def _sample_for(param: dict):
    schema = param.get("schema") or {}
    if "example" in param:
        return param["example"]
    if "example" in schema:
        return schema["example"]
    if schema.get("enum"):
        return schema["enum"][0]
    if "default" in schema:
        return schema["default"]
    t = schema.get("type")
    fmt = schema.get("format")
    if fmt == "date":
        return "2026-01-01"
    if fmt == "date-time":
        return "2026-01-01T00:00:00Z"
    return {"integer": 1, "number": 1, "boolean": "true",
            "array": "", "string": "test"}.get(t, "test")


def required_query(endpoint) -> dict:
    return {p["name"]: _sample_for(p) for p in endpoint.required_query if p.get("name")}


def sensible_query(endpoint) -> dict:
    """Required params plus `range`, which most dashboard/report endpoints want."""
    q = required_query(endpoint)
    names = {p.get("name") for p in endpoint.query_params}
    if "range" in names and "range" not in q:
        q["range"] = "month"
    return q


# Payloads that must be handled, not crashed on. Every one of these is a string
# a real user can type into a search box.
# Six distinct ideas, not eleven spellings of three. `sql-quote`,
# `sql-tautology` and `sql-comment` all asked "is this interpolated into a
# query"; one of them answers it. Same for `xss` and `template`.
HOSTILE_STRINGS = {
    "sql-injection": "1' OR '1'='1; DROP TABLE salons --",
    "markup": "<script>alert(1)</script>{{7*7}}",
    "nul-byte": "a\x00b",
    "unicode": "\U0001f4a5é你好",
    "very-long": "A" * 5000,
    "wrong-shape": "[1,2,3]",
}
