"""Thin requests wrapper: path-param substitution, timing, and readable failures."""
from __future__ import annotations

import json as jsonlib
import re
import time
from dataclasses import dataclass

import requests

PATH_PARAM = re.compile(r"\{([^}]+)\}")

REQUEST_COUNT = {"n": 0}


@dataclass
class Result:
    response: requests.Response
    elapsed: float
    method: str
    url: str

    @property
    def status(self) -> int:
        return self.response.status_code

    @property
    def json(self):
        try:
            return self.response.json()
        except ValueError:
            return None

    @property
    def data(self):
        """Every controller wraps success payloads as {data: ..., token: ...}."""
        body = self.json
        return body.get("data") if isinstance(body, dict) else None

    @property
    def error(self):
        body = self.json
        if not isinstance(body, dict):
            return None
        # ApplicationController#authorize_request uses `errors`; every other
        # failure path uses `error`. Both are accepted here on purpose - the
        # inconsistency is asserted on in test_contract_robustness.
        return body.get("error") or body.get("errors")

    def explain(self) -> str:
        body = self.response.text or ""
        if len(body) > 600:
            body = body[:600] + f"... [{len(self.response.text)} bytes]"
        return (f"\n  {self.method} {self.url}"
                f"\n  -> {self.status} in {self.elapsed * 1000:.0f}ms"
                f"\n  body: {body}")


class ApiClient:
    def __init__(self, base_url: str, token: str | None = None,
                 timeout: int = 30, label: str = "client"):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self.label = label
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "User-Agent": "nearz-api-tests/1.0",
        })
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"

    # -- url building -------------------------------------------------------
    def build(self, path: str, **path_params) -> str:
        """Substitute {salon_id} style segments. Missing ones raise loudly."""
        def sub(match):
            name = match.group(1)
            if name not in path_params:
                raise KeyError(
                    f"{path} needs path param '{name}'; got {sorted(path_params)}")
            return str(path_params[name])
        return self.base_url + PATH_PARAM.sub(sub, path)

    # -- request ------------------------------------------------------------
    def request(self, method: str, path: str, *, path_params=None,
                params=None, json=None, data=None, headers=None,
                allow_redirects=False) -> Result:
        url = self.build(path, **(path_params or {}))
        REQUEST_COUNT["n"] += 1
        start = time.perf_counter()
        resp = self.session.request(
            method.upper(), url, params=params, json=json, data=data,
            headers=headers, timeout=self.timeout, allow_redirects=allow_redirects)
        return Result(resp, time.perf_counter() - start, method.upper(), url)

    def get(self, path, **kw):
        return self.request("GET", path, **kw)

    def post(self, path, **kw):
        return self.request("POST", path, **kw)

    def put(self, path, **kw):
        return self.request("PUT", path, **kw)

    def patch(self, path, **kw):
        return self.request("PATCH", path, **kw)

    def delete(self, path, **kw):
        return self.request("DELETE", path, **kw)

    def raw(self, method: str, url: str, **kw) -> Result:
        """Absolute-URL escape hatch (public invoice links, redirects)."""
        start = time.perf_counter()
        resp = self.session.request(method.upper(), url, timeout=self.timeout, **kw)
        return Result(resp, time.perf_counter() - start, method.upper(), url)

    def __repr__(self):
        return f"<ApiClient {self.label} {self.base_url}>"


def send_raw_body(client: ApiClient, method: str, path: str, body: str,
                  content_type="application/json", **path_params) -> Result:
    """Post a byte-for-byte body - used to send deliberately malformed JSON."""
    url = client.build(path, **path_params)
    start = time.perf_counter()
    resp = client.session.request(
        method.upper(), url, data=body.encode("utf-8"),
        headers={"Content-Type": content_type}, timeout=client.timeout)
    return Result(resp, time.perf_counter() - start, method.upper(), url)
