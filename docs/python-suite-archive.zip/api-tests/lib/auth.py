"""Token acquisition.

Two paths, both supported so the suite runs whichever way your QA env allows:

  1. Paste a JWT into .env (OWNER_TOKEN). Fastest, expires in 24h.
  2. Log in through the API (OWNER_MOBILE). AuthenticationController#verify
     accepts OTP 3227 when the Origin header contains "netlify", and 2244 for
     the five TEST_MOBILE_NO numbers - so no real SMS is needed in QA.

Path 2 is preferred for CI: tokens expire, mobiles don't.
"""
from __future__ import annotations

import requests

NETLIFY_OTP = "3227"
TEST_MOBILE_OTP = "2244"
TEST_MOBILES = {
    "+911233211231", "+911233211232", "+911233211233",
    "+911233211234", "+911233211235",
}


class LoginError(RuntimeError):
    pass


def login(base_url: str, mobile: str, origin: str, timeout: int = 30) -> dict:
    """sign_up -> verify. Returns the decoded body of verify (data + token)."""
    base = base_url.rstrip("/")
    headers = {"Origin": origin, "Accept": "application/json"}

    signup = requests.post(f"{base}/sign_up",
                           json={"mobile": mobile, "username": "api-tests"},
                           headers=headers, timeout=timeout)
    if signup.status_code not in (200, 201):
        raise LoginError(f"sign_up for {mobile} returned {signup.status_code}: "
                         f"{signup.text[:300]}")

    otp = TEST_MOBILE_OTP if mobile in TEST_MOBILES else NETLIFY_OTP
    verify = requests.post(f"{base}/verify",
                           json={"mobile": mobile, "code": otp},
                           headers=headers, timeout=timeout)
    if verify.status_code != 200:
        raise LoginError(f"verify for {mobile} returned {verify.status_code}: "
                         f"{verify.text[:300]}")

    token = verify.headers.get("token")
    body = {}
    try:
        body = verify.json()
    except ValueError:
        pass
    token = token or body.get("token")
    if not token:
        raise LoginError(f"verify succeeded but returned no token: {verify.text[:300]}")
    return {"token": token, "body": body}


def salon_id_from(body: dict):
    """Dig the caller's salon id out of the verify payload."""
    data = (body or {}).get("data") or {}
    for key in ("salon_id", "salon"):
        val = data.get(key)
        if isinstance(val, dict):
            return val.get("id")
        if val:
            return val
    user = data.get("user") or {}
    if isinstance(user, dict):
        salon = user.get("salon")
        if isinstance(salon, dict):
            return salon.get("id")
        if user.get("salon_id"):
            return user["salon_id"]
    return None


# A syntactically valid JWT signed with the wrong key - must be rejected as
# firmly as a garbage string, and proves the API verifies the signature rather
# than merely parsing the token.
FORGED_JWT = (
    "eyJhbGciOiJIUzI1NiJ9."
    "eyJ1c2VyX2lkIjo5OTk5OTk5LCJyb2xlIjoiYWRtaW4iLCJleHAiOjQxMDI0NDQ4MDB9."
    "aW52YWxpZHNpZ25hdHVyZWludmFsaWRzaWduYXR1cmVpbnY"
)

GARBAGE_TOKENS = {
    "empty": "",
    "not-a-jwt": "hello-world",
    "forged-signature": FORGED_JWT,
    "expired-shape": "a.b.c",
}
