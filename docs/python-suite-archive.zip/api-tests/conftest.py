"""Shared fixtures and configuration for the Nearz B2B API test suite."""
from __future__ import annotations

import os
import sys
import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv  # noqa: E402
from lib.auth import login, salon_id_from, LoginError  # noqa: E402
from lib.client import ApiClient  # noqa: E402

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))


# --------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------
def _env(name, default=None):
    val = os.getenv(name, default)
    return val.strip() if isinstance(val, str) else val


def pytest_addoption(parser):
    parser.addoption("--base-url", action="store", default=None,
                     help="Override BASE_URL from .env")
    parser.addoption("--run-destructive", action="store_true", default=False,
                     help="Include tests that create or modify data")
    parser.addoption("--module", action="store", default=None,
                     help="Restrict contract tests to one module, e.g. --module=Billing")


@pytest.fixture(scope="session")
def config(request):
    base = request.config.getoption("--base-url") or _env("BASE_URL")
    if not base or "example.com" in base:
        pytest.exit(
            "BASE_URL is not set. Copy .env.example to .env and fill in the QA "
            "API host (DevTools > Network on the dashboard > any XHR).", returncode=2)
    return {
        "base_url": base.rstrip("/"),
        "timeout": int(_env("REQUEST_TIMEOUT", "30")),
        "sla": float(_env("SLA_SECONDS", "0") or 0),
        "origin": _env("LOGIN_ORIGIN", "https://nearz-b2b-qa.netlify.app"),
        "module_filter": request.config.getoption("--module"),
    }


def _resolve_identity(config, token_var, mobile_var, salon_var, label):
    """Return (token, salon_id) using a pasted token or an API login."""
    token = _env(token_var)
    salon = _env(salon_var)
    if token:
        return token, salon
    mobile = _env(mobile_var)
    if not mobile:
        return None, None
    try:
        result = login(config["base_url"], mobile, config["origin"], config["timeout"])
    except LoginError as exc:
        pytest.skip(f"{label} login failed: {exc}")
    return result["token"], salon or salon_id_from(result["body"])


# --------------------------------------------------------------------------
# identities
# --------------------------------------------------------------------------
@pytest.fixture(scope="session")
def owner_identity(config):
    token, salon = _resolve_identity(config, "OWNER_TOKEN", "OWNER_MOBILE",
                                     "OWNER_SALON_ID", "owner")
    if not token:
        pytest.exit("No OWNER_TOKEN or OWNER_MOBILE in .env - nothing can run.",
                    returncode=2)
    if not salon:
        pytest.exit("OWNER_SALON_ID is required (the id in the dashboard's "
                    "/salons/<id>/... requests).", returncode=2)
    return {"token": token, "salon_id": salon}


@pytest.fixture(scope="session")
def other_identity(config):
    token, salon = _resolve_identity(config, "OTHER_TOKEN", "OTHER_MOBILE",
                                     "OTHER_SALON_ID", "second salon")
    if not token or not salon:
        return None
    return {"token": token, "salon_id": salon}


# --------------------------------------------------------------------------
# clients
# --------------------------------------------------------------------------
@pytest.fixture(scope="session")
def api(config, owner_identity):
    """Authenticated as the salon owner. The default client."""
    return ApiClient(config["base_url"], owner_identity["token"],
                     config["timeout"], label="owner")


@pytest.fixture(scope="session")
def api_other(config, other_identity):
    """Authenticated as a DIFFERENT salon's owner. Skips if not configured."""
    if not other_identity:
        pytest.skip("OTHER_TOKEN/OTHER_SALON_ID not set - tenant isolation "
                    "cannot be tested without a second salon.")
    return ApiClient(config["base_url"], other_identity["token"],
                     config["timeout"], label="other-salon")


@pytest.fixture(scope="session")
def journey_identity(config):
    """The salon that mutating journeys are allowed to write to.

    Falls back to the owner salon when unset, so nothing breaks - but every
    journey then leaves settled bills on the live QA salon, which is how 4536
    ended up unusable for exact-delta assertions. Set JOURNEY_SALON_ID.
    """
    token, salon = _resolve_identity(config, "JOURNEY_TOKEN", "JOURNEY_MOBILE",
                                     "JOURNEY_SALON_ID", "journey salon")
    if not token or not salon:
        return None
    return {"token": token, "salon_id": salon}


@pytest.fixture(scope="session")
def api_journey(config, journey_identity, api):
    """Write client for journeys. Never 4536 when JOURNEY_TOKEN is set."""
    if not journey_identity:
        return api
    return ApiClient(config["base_url"], journey_identity["token"],
                     config["timeout"], label="journey-salon")


@pytest.fixture(scope="session")
def journey_salon_id(journey_identity, salon_id):
    return journey_identity["salon_id"] if journey_identity else salon_id


@pytest.fixture(scope="session")
def api_anon(config):
    """No Authorization header at all."""
    return ApiClient(config["base_url"], None, config["timeout"], label="anonymous")


@pytest.fixture(scope="session")
def api_admin(config):
    token = _env("ADMIN_TOKEN")
    if not token:
        pytest.skip("ADMIN_TOKEN not set")
    return ApiClient(config["base_url"], token, config["timeout"], label="admin")


@pytest.fixture(scope="session")
def salon_id(owner_identity):
    return owner_identity["salon_id"]


@pytest.fixture(scope="session")
def other_salon_id(other_identity):
    if not other_identity:
        pytest.skip("OTHER_SALON_ID not set")
    return other_identity["salon_id"]


@pytest.fixture(scope="session")
def sla(config):
    return config["sla"]


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------
def pytest_report_header(config):
    """`config` here is pytest's Config object, not the session fixture of the
    same name - hook argument names are fixed by pytest."""
    base = os.getenv("BASE_URL", "<unset>")
    return [f"Nearz B2B API suite  |  target: {base}",
            "destructive tests: " + ("ON" if config.getoption("--run-destructive")
                                     else "off (--run-destructive to enable)")]



# ==========================================================================
# Automatic module + priority tagging
# ==========================================================================
# Every test gets two markers it did not have to declare:
#
#   module_<name>   which of the 8 B2B modules it exercises, worked out from
#                   the endpoint in its parameter id, or from its file
#   P1 | P2 | P3    how bad it is if this test fails
#
# so `pytest -m "P1 and module_billing"` works without anyone maintaining a list.

import re as _re

_MODULE_BY_PATH = [
    (r"/reports/",                                   "reports"),
    (r"/dashboard/|/enquiries|/follow_up_tasks",     "dashboard"),
    (r"/billing/|/bills|/customer_memberships|/membership_plans", "billing"),
    (r"/appointments|/waitlist|/resources|/calendar", "calendar"),
    (r"/attendance",                                 "attendance"),
    (r"/settings|/working_days|/holidays|/roles|/taxes|/notification_preferences", "settings"),
    (r"/salon_customer_profiles|/profile_attribute_options", "customers"),
    (r"/salon_services|/products|/staff|/product_brands|/product_categories", "setup"),
]

_MODULE_BY_FILE = {
    "test_dashboard": "dashboard", "test_reports": "reports", "test_billing": "billing",
    "test_salon_setup": "setup", "test_attendance": "attendance",
    "test_appointment_calendar": "calendar", "test_settings": "settings",
    "test_arithmetic": "billing", "test_reconciliation": "reports",
    "test_journey_arithmetic": "reports", "test_salon_journey": "crosscutting",
}

MODULE_LABEL = {
    "dashboard": "Business Dashboard", "calendar": "Appointment Calendar",
    "reports": "Reports", "billing": "Billing", "customers": "Customers",
    "setup": "Salon Setup", "attendance": "Attendance", "settings": "Salon Settings",
    "crosscutting": "Cross-cutting",
}


def _module_for(item):
    nodeid = item.nodeid
    param = nodeid.partition("[")[2]
    for pattern, name in _MODULE_BY_PATH:
        if _re.search(pattern, param):
            return name
    stem = nodeid.split("/")[-1].partition(".py")[0]
    return _MODULE_BY_FILE.get(stem, "crosscutting")


def _priority_for(item, marks, module):
    """P1  a failure means money is wrong, data leaked, or the core flow broke.
    P2  a failure means the API disagrees with its own contract or its own rules.
    P3  hardening — malformed input, injection, boundaries.
    """
    if marks & {"smoke", "auth", "tenant", "arithmetic", "reconciliation"}:
        return "P1"
    if "journey" in marks:
        return "P1"
    if "functional" in marks and module == "billing":
        return "P1"
    if "robustness" in marks:
        return "P3"
    return "P2"


def pytest_collection_modifyitems(config, items):
    """Tags every test with its module and priority, then applies the
    destructive filter."""
    skip_destructive = None
    if not config.getoption("--run-destructive"):
        skip_destructive = pytest.mark.skip(
            reason="destructive; re-run with --run-destructive")

    for item in items:
        marks = {m.name for m in item.iter_markers()}
        module = _module_for(item)
        priority = _priority_for(item, marks, module)
        item.add_marker(getattr(pytest.mark, f"module_{module}"))
        item.add_marker(getattr(pytest.mark, priority))
        item.user_properties.append(("module", MODULE_LABEL[module]))
        item.user_properties.append(("priority", priority))
        if skip_destructive is not None and "destructive" in item.keywords:
            item.add_marker(skip_destructive)


# ==========================================================================
# Known-issues baseline — so a daily run reports what is NEW
# ==========================================================================
# A suite that says "106 failed" every morning trains people to close the tab.
# Every currently-failing test is recorded in known-issues.txt with the bug it
# belongs to. After each run we write out/new-failures.md containing only what
# is not on that list — plus anything on the list that has started passing,
# which usually means a fix shipped.

import os as _os

_BASELINE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "known-issues.txt")
_OUTDIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "out")


def _load_baseline():
    known = {}
    if not _os.path.exists(_BASELINE):
        return known
    for line in open(_BASELINE, encoding="utf-8"):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        nodeid, _, note = line.partition("#")
        known[nodeid.strip()] = note.strip() or "no bug reference"
    return known


# Failure tracking is NOT done in-process: under `-n 8` each worker is a
# separate process and the master never sees their results. pytest's JUnit XML
# is written correctly either way, so tools/new_failures.py reads that instead.


def pytest_sessionfinish(session, exitstatus):
    try:
        from lib.client import REQUEST_COUNT
        if REQUEST_COUNT["n"]:
            print(f"\n>>> HTTP REQUESTS MADE: {REQUEST_COUNT['n']}")
    except Exception:
        pass
